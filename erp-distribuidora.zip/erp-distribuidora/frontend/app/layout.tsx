"use client";
import "./globals.css";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { LayoutDashboard, Truck, ShoppingCart, Receipt, Store, Landmark, FileText, Menu, X, LogOut } from "lucide-react";
import { AuthProvider, useAuth, type Role } from "@/lib/auth";

// Deve refletir as permissões da API (ADMIN vê tudo). A API é quem de fato bloqueia.
const rotas: { href: string; label: string; I: typeof Menu; roles: Role[] }[] = [
  { href: "/dashboard", label: "Visão geral", I: LayoutDashboard, roles: ["GERENTE", "FINANCEIRO"] },
  { href: "/fornecedores", label: "Fornecedores", I: Truck, roles: ["GERENTE", "ESTOQUISTA"] },
  { href: "/compras", label: "Compras", I: ShoppingCart, roles: ["GERENTE", "ESTOQUISTA"] },
  { href: "/vendas", label: "Vendas (Atacado)", I: Receipt, roles: ["GERENTE", "VENDEDOR"] },
  { href: "/pdv", label: "PDV (Varejo)", I: Store, roles: ["GERENTE", "CAIXA"] },
  { href: "/financeiro", label: "Financeiro", I: Landmark, roles: ["GERENTE", "FINANCEIRO"] },
  { href: "/fiscal", label: "Notas fiscais", I: FileText, roles: ["GERENTE", "FINANCEIRO"] },
];

function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname(), router = useRouter(), { user, logout } = useAuth();
  const [aberto, setAberto] = useState(false);
  const menu = rotas.filter((r) => user && (user.role === "ADMIN" || r.roles.includes(user.role)));

  useEffect(() => {
    if (user === undefined) return;
    if (!user && path !== "/login") router.replace("/login");
    if (user && path === "/login") router.replace(menu[0]?.href ?? "/dashboard");
  }, [user, path]); // eslint-disable-line react-hooks/exhaustive-deps

  if (user === undefined) return <p className="p-8 text-sm text-slate-500">Carregando…</p>;
  if (path === "/login") return <>{children}</>;
  if (!user) return null;

  return (
    <div className="flex min-h-screen bg-slate-50">
      <button onClick={() => setAberto(true)} aria-label="Abrir menu" className="fixed left-3 top-3 z-30 rounded-lg bg-white p-2 shadow md:hidden"><Menu size={20} /></button>
      {aberto && <div className="fixed inset-0 z-30 bg-slate-900/40 md:hidden" onClick={() => setAberto(false)} />}
      <aside className={`fixed z-40 flex h-full w-60 shrink-0 flex-col border-r border-slate-200 bg-white p-4 transition-transform md:static md:translate-x-0 ${aberto ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="mb-6 flex items-center justify-between">
          <span className="text-lg font-semibold text-teal-800">Distribui<span className="text-amber-600">ERP</span></span>
          <button onClick={() => setAberto(false)} aria-label="Fechar menu" className="md:hidden"><X size={18} /></button>
        </div>
        <nav className="flex-1 space-y-1">
          {menu.map(({ href, label, I }) => (
            <Link key={href} href={href} onClick={() => setAberto(false)}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm ${path === href ? "bg-teal-50 font-medium text-teal-800" : "text-slate-600 hover:bg-slate-100"}`}>
              <I size={18} /> {label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-slate-100 pt-3 text-sm">
          <p className="truncate font-medium text-slate-800">{user.name}</p>
          <p className="mb-2 text-xs text-slate-500">{user.role}</p>
          <button onClick={logout} className="flex items-center gap-2 text-slate-600 hover:text-slate-900"><LogOut size={16} /> Sair</button>
        </div>
      </aside>
      <div className="min-w-0 flex-1 pt-10 md:pt-0">{children}</div>
    </div>
  );
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body><AuthProvider><Shell>{children}</Shell></AuthProvider></body>
    </html>
  );
}

import { NextResponse } from "next/server";

// Consulta pública do CNPJ.ws; troque por ReceitaWS ou pelo seu backend se preferir.
export async function GET(_: Request, { params }: { params: Promise<{ cnpj: string }> }) {
  const { cnpj } = await params;
  const digits = cnpj.replace(/\D/g, "");
  if (digits.length !== 14) return NextResponse.json({ error: "CNPJ inválido" }, { status: 400 });

  const res = await fetch(`https://publica.cnpj.ws/cnpj/${digits}`, { next: { revalidate: 3600 } });
  if (!res.ok) return NextResponse.json({ error: "CNPJ não encontrado ou limite de consultas atingido" }, { status: res.status });

  const d = await res.json();
  const e = d.estabelecimento ?? {};
  return NextResponse.json({
    razao: d.razao_social,
    fantasia: e.nome_fantasia ?? "",
    ie: e.inscricoes_estaduais?.find((i: any) => i.ativo)?.inscricao_estadual ?? "",
    endereco: [e.tipo_logradouro, e.logradouro, e.numero, e.bairro, e.cidade?.nome && `${e.cidade.nome}/${e.estado?.sigla}`, e.cep].filter(Boolean).join(", "),
    telefone: e.ddd1 && e.telefone1 ? `(${e.ddd1}) ${e.telefone1}` : "",
    email: e.email ?? "",
  });
}

"use client";
import { useState } from "react";
import { z } from "zod";
import { Eye, Pencil, Trash2, Plus, FileText, Ban, X, Loader2 } from "lucide-react";
import { brl, catalogo, cancelarNotaMock, emitirNotaMock, precoAtacado } from "@/lib/mock";

type Status = "Aguardando emissão" | "Faturada" | "Cancelada";
type Linha = { sku: string; qtd: number };
type Venda = { id: string; numero: number; cliente: string; pagamento: "Boleto" | "PIX" | "A prazo"; vencimento: string; itens: Linha[]; status: Status; chave?: string };

const clientes = ["Mercadinho Boa Vista", "Restaurante Sabor do Mar", "Padaria Pão Quente"];
const cor: Record<Status, string> = { "Aguardando emissão": "bg-amber-100 text-amber-800", Faturada: "bg-emerald-100 text-emerald-800", Cancelada: "bg-red-100 text-red-800" };
const subtotal = (it: Linha[]) => it.reduce((a, l) => { const p = catalogo.find((x) => x.sku === l.sku); return a + (p ? precoAtacado(p, l.qtd) * l.qtd : 0); }, 0);

const schema = z.object({
  cliente: z.string().min(1, "Escolha o cliente"),
  vencimento: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Informe o vencimento"),
  itens: z.array(z.object({ sku: z.string().min(1), qtd: z.number().positive() })).min(1, "Adicione ao menos um item com quantidade maior que zero"),
});

export default function VendasPage() {
  const [vendas, setVendas] = useState<Venda[]>([
    { id: "1", numero: 2051, cliente: clientes[0], pagamento: "Boleto", vencimento: "2026-10-30", itens: [{ sku: "LEI-001", qtd: 60 }], status: "Aguardando emissão" },
    { id: "2", numero: 2050, cliente: clientes[1], pagamento: "PIX", vencimento: "2026-10-10", itens: [{ sku: "ARR-030", qtd: 8 }], status: "Faturada", chave: "26261012345678000199550010000020501000020509" },
  ]);
  const [modal, setModal] = useState<null | { mode: "novo" | "ver" | "editar" | "excluir"; id?: string }>(null);
  const [cliente, setCliente] = useState(""); const [pagamento, setPagamento] = useState<Venda["pagamento"]>("Boleto");
  const [vencimento, setVencimento] = useState(""); const [itens, setItens] = useState<Linha[]>([{ sku: "", qtd: 1 }]);
  const [erro, setErro] = useState(""); const [ocupado, setOcupado] = useState<string | null>(null); const [msg, setMsg] = useState("");

  const atual = vendas.find((v) => v.id === modal?.id);
  const ro = modal?.mode === "ver" || (modal?.mode === "editar" && atual?.status !== "Aguardando emissão");
  const nextNum = Math.max(2000, ...vendas.map((v) => v.numero)) + 1;

  function abrir(mode: "novo" | "ver" | "editar" | "excluir", v?: Venda) {
    setCliente(v?.cliente ?? ""); setPagamento(v?.pagamento ?? "Boleto"); setVencimento(v?.vencimento ?? "");
    setItens(v ? v.itens.map((i) => ({ ...i })) : [{ sku: "", qtd: 1 }]); setErro(""); setModal({ mode, id: v?.id });
  }
  const fechar = () => setModal(null);

  function salvar() {
    const r = schema.safeParse({ cliente, vencimento, itens });
    if (!r.success) return setErro(r.error.issues[0].message);
    if (modal?.mode === "editar") setVendas((l) => l.map((v) => (v.id === modal.id ? { ...v, cliente, pagamento, vencimento, itens } : v)));
    else setVendas((l) => [{ id: crypto.randomUUID(), numero: nextNum, cliente, pagamento, vencimento, itens, status: "Aguardando emissão" }, ...l]);
    fechar(); // TODO: POST/PATCH /api/sales
  }

  async function emitir(v: Venda) {
    setOcupado(v.id); setMsg("");
    const n = await emitirNotaMock(55); // TODO: POST /api/fiscal/emitir { saleId, model: 55 }
    setVendas((l) => l.map((x) => (x.id === v.id ? { ...x, status: "Faturada", chave: n.chave } : x)));
    setMsg(`NF-e da venda ${v.numero} autorizada (protocolo ${n.protocolo}, ambiente simulado).`); setOcupado(null);
  }
  async function cancelarNota(v: Venda) {
    setOcupado(v.id); await cancelarNotaMock(); // TODO: evento de cancelamento na SEFAZ
    setVendas((l) => l.map((x) => (x.id === v.id ? { ...x, status: "Cancelada" } : x))); setMsg(`NF-e da venda ${v.numero} cancelada.`); setOcupado(null);
  }

  const inp = "w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm disabled:bg-slate-50";
  return (
    <main className="p-4 md:p-8">
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-semibold text-slate-900">Vendas · Atacado</h1><p className="text-sm text-slate-500">Preço progressivo por quantidade e faturamento a prazo</p></div>
        <button onClick={() => abrir("novo")} className="flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800"><Plus size={16} /> Nova venda</button>
      </header>
      {msg && <p className="mb-4 rounded-lg bg-teal-50 px-4 py-2 text-sm text-teal-900" role="status">{msg}</p>}

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="bg-slate-50 text-xs text-slate-500"><tr>{["Venda", "Cliente", "Pagamento", "Vencimento", "Total", "Status", "Ações"].map((c) => <th key={c} className={`px-4 py-3 font-medium ${c === "Ações" ? "text-right" : ""}`}>{c}</th>)}</tr></thead>
          <tbody>
            {vendas.map((v) => (
              <tr key={v.id} className="border-t border-slate-100">
                <td className="px-4 py-3 font-medium">#{v.numero}</td><td className="px-4">{v.cliente}</td><td className="px-4">{v.pagamento}</td>
                <td className="px-4">{v.vencimento.split("-").reverse().join("/")}</td><td className="px-4">{brl(subtotal(v.itens))}</td>
                <td className="px-4"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${cor[v.status]}`}>{v.status}</span></td>
                <td className="px-4">
                  <div className="flex items-center justify-end gap-1">
                    {v.status === "Aguardando emissão" && <button disabled={!!ocupado} onClick={() => emitir(v)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-teal-800 hover:bg-teal-50 disabled:opacity-50">{ocupado === v.id ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />} Emitir NF-e</button>}
                    {v.status === "Faturada" && <button disabled={!!ocupado} onClick={() => cancelarNota(v)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-red-700 hover:bg-red-50 disabled:opacity-50"><Ban size={14} /> Cancelar NF-e</button>}
                    {([[Eye, "Visualizar", "ver"], [Pencil, "Editar", "editar"], [Trash2, "Excluir", "excluir"]] as const).map(([I, l, m]) => (
                      <button key={l} title={l} aria-label={l} onClick={() => abrir(m, v)} className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"><I size={16} /></button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
            {!vendas.length && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-500">Nenhuma venda registrada.</td></tr>}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-slate-900/40 p-4" onClick={fechar} role="dialog" aria-modal="true">
          <div className="w-full max-w-2xl rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-semibold">{{ novo: "Nova venda (atacado)", ver: `Venda #${atual?.numero}`, editar: `Editar venda #${atual?.numero}`, excluir: "Excluir venda" }[modal.mode]}</h2>
              <button onClick={fechar} aria-label="Fechar" className="rounded p-1 hover:bg-slate-100"><X size={18} /></button>
            </div>
            {modal.mode === "excluir" ? (
              <>
                <p className="text-sm">Excluir a venda <strong>#{atual?.numero}</strong>?{atual?.status === "Faturada" && " Há NF-e autorizada: cancele a nota antes de excluir."}</p>
                <div className="mt-5 flex justify-end gap-2">
                  <button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
                  <button disabled={atual?.status === "Faturada"} onClick={() => { setVendas((l) => l.filter((v) => v.id !== modal.id)); fechar(); }} className="rounded-lg bg-red-600 px-4 py-2 text-sm text-white disabled:opacity-50">Excluir</button>
                </div>
              </>
            ) : (
              <div className="space-y-3">
                {modal.mode === "editar" && ro && <p className="rounded-lg bg-slate-100 px-3 py-2 text-xs">Vendas faturadas ou canceladas não podem ser alteradas.</p>}
                <div className="grid gap-3 sm:grid-cols-3">
                  <label className="block text-sm">Cliente<select disabled={ro} value={cliente} onChange={(e) => setCliente(e.target.value)} className={`mt-1 ${inp}`}><option value="">Selecione…</option>{clientes.map((c) => <option key={c}>{c}</option>)}</select></label>
                  <label className="block text-sm">Pagamento<select disabled={ro} value={pagamento} onChange={(e) => setPagamento(e.target.value as Venda["pagamento"])} className={`mt-1 ${inp}`}>{["Boleto", "PIX", "A prazo"].map((p) => <option key={p}>{p}</option>)}</select></label>
                  <label className="block text-sm">Vencimento<input disabled={ro} type="date" value={vencimento} onChange={(e) => setVencimento(e.target.value)} className={`mt-1 ${inp}`} /></label>
                </div>
                <div className="space-y-2">
                  {itens.map((it, i) => {
                    const p = catalogo.find((x) => x.sku === it.sku); const pu = p ? precoAtacado(p, it.qtd) : 0;
                    return (
                      <div key={i} className="grid grid-cols-[1fr_80px_90px_32px] items-center gap-2">
                        <select disabled={ro} aria-label="Produto" value={it.sku} onChange={(e) => setItens((l) => l.map((x, j) => (j === i ? { ...x, sku: e.target.value } : x)))} className={inp}><option value="">Produto…</option>{catalogo.filter((c) => !c.porKg).map((c) => <option key={c.sku} value={c.sku}>{c.nome}</option>)}</select>
                        <input disabled={ro} type="number" min="1" aria-label="Quantidade em caixas" value={it.qtd} onChange={(e) => setItens((l) => l.map((x, j) => (j === i ? { ...x, qtd: +e.target.value } : x)))} className={inp} />
                        <span className="text-right text-xs text-slate-600">{p ? `${brl(pu)} /un` : "—"}</span>
                        {!ro && <button onClick={() => setItens((l) => l.filter((_, j) => j !== i))} aria-label="Remover item" className="rounded p-1 text-slate-500 hover:bg-slate-100"><Trash2 size={16} /></button>}
                      </div>
                    );
                  })}
                  {!ro && <button onClick={() => setItens((l) => [...l, { sku: "", qtd: 1 }])} className="text-sm text-teal-800">+ Adicionar item</button>}
                </div>
                <p className="text-right text-sm">Total: <strong>{brl(subtotal(itens))}</strong></p>
                {atual?.chave && <p className="break-all text-xs text-slate-500">Chave da NF-e: {atual.chave}</p>}
                {erro && <p className="text-sm text-red-600">{erro}</p>}
                <div className="flex justify-end gap-2 pt-1">
                  <button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">{ro ? "Fechar" : "Cancelar"}</button>
                  {!ro && <button onClick={salvar} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">{modal.mode === "novo" ? "Registrar venda" : "Salvar alterações"}</button>}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
}

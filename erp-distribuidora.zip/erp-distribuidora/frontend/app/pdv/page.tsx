"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Pencil, Trash2, Check, X, Loader2, Scale, ScanBarcode } from "lucide-react";
import { brl, catalogo, emitirNotaMock, type Prod } from "@/lib/mock";

type Linha = { prod: Prod; qtd: number };
type Pgto = "Dinheiro" | "PIX" | "Débito" | "Crédito";
type Recibo = { chave: string; protocolo: string; total: number; pgto: string; troco: number };

export default function PdvPage() {
  const [cart, setCart] = useState<Linha[]>([]);
  const [codigo, setCodigo] = useState("");
  const [peso, setPeso] = useState("");
  const [pendentePeso, setPendentePeso] = useState<Prod | null>(null);
  const [editando, setEditando] = useState<number | null>(null);
  const [pgto, setPgto] = useState<Pgto>("Dinheiro");
  const [parcelas, setParcelas] = useState(1);
  const [recebido, setRecebido] = useState("");
  const [aviso, setAviso] = useState("");
  const [emitindo, setEmitindo] = useState(false);
  const [recibo, setRecibo] = useState<Recibo | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, [cart.length, recibo]);
  const total = useMemo(() => cart.reduce((a, l) => a + l.prod.precoVarejo * l.qtd, 0), [cart]);
  const troco = pgto === "Dinheiro" ? Math.max(0, (parseFloat(recebido) || 0) - total) : 0;

  function adicionar(prod: Prod, qtd = 1) {
    setCart((c) => {
      const i = c.findIndex((l) => l.prod.sku === prod.sku);
      return i >= 0 && !prod.porKg ? c.map((l, j) => (j === i ? { ...l, qtd: l.qtd + qtd } : l)) : [...c, { prod, qtd }];
    });
  }
  function lerCodigo(e: React.FormEvent) {
    e.preventDefault(); setAviso("");
    const q = codigo.trim().toLowerCase(); if (!q) return;
    const prod = catalogo.find((p) => p.barcode === q || p.sku.toLowerCase() === q);
    setCodigo("");
    if (!prod) return setAviso(`Produto "${q}" não encontrado.`);
    if (prod.porKg) { setPendentePeso(prod); setPeso(""); } else adicionar(prod);
  }
  // Balança: aqui digitado. Em produção, ler via Web Serial API / agente local e preencher `peso`.
  function confirmarPeso() {
    const kg = parseFloat(peso.replace(",", "."));
    if (!pendentePeso || !(kg > 0)) return setAviso("Informe um peso válido em kg.");
    adicionar(pendentePeso, kg); setPendentePeso(null); setAviso("");
  }

  async function finalizar() {
    if (!cart.length) return setAviso("Adicione itens antes de finalizar.");
    if (pgto === "Dinheiro" && (parseFloat(recebido) || 0) < total) return setAviso("Valor recebido menor que o total.");
    setEmitindo(true); setAviso("");
    const n = await emitirNotaMock(65); // TODO: POST /api/pdv/finalizar { itens, pagamento } → baixa estoque + NFC-e
    setRecibo({ chave: n.chave, protocolo: n.protocolo, total, troco, pgto: pgto === "Crédito" ? `Crédito ${parcelas}x` : pgto });
    setEmitindo(false);
  }
  function novaVenda() { setCart([]); setRecibo(null); setRecebido(""); setParcelas(1); setPgto("Dinheiro"); setEditando(null); }

  const inp = "rounded-lg border border-slate-300 px-3 py-2 text-sm";
  return (
    <main className="grid gap-4 p-4 md:p-8 lg:grid-cols-[1fr_340px]">
      <section>
        <h1 className="mb-1 text-2xl font-semibold text-slate-900">PDV · Varejo</h1>
        <p className="mb-4 text-sm text-slate-500">Leia o código de barras (ou digite o SKU) e pressione Enter</p>
        <form onSubmit={lerCodigo} className="mb-3 flex gap-2">
          <div className="relative flex-1"><ScanBarcode size={18} className="absolute left-3 top-2.5 text-slate-400" />
            <input ref={inputRef} value={codigo} onChange={(e) => setCodigo(e.target.value)} placeholder="Código de barras ou SKU" className={`${inp} w-full pl-10`} aria-label="Código de barras" /></div>
          <button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Adicionar</button>
        </form>
        {aviso && <p className="mb-3 text-sm text-red-600" role="alert">{aviso}</p>}
        <p className="mb-2 text-xs text-slate-400">Teste: 7891000100103 (leite) · 2000000000401 (queijo, pesado na balança)</p>

        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full min-w-[520px] text-left text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500"><tr>{["Item", "Qtd", "Unitário", "Subtotal", "Ações"].map((c) => <th key={c} className={`px-4 py-3 font-medium ${c === "Ações" ? "text-right" : ""}`}>{c}</th>)}</tr></thead>
            <tbody>
              {cart.map((l, i) => (
                <tr key={i} className="border-t border-slate-100">
                  <td className="px-4 py-3">{l.prod.nome}</td>
                  <td className="px-4">
                    <input disabled={editando !== i} type="number" min="0" step={l.prod.porKg ? "0.001" : "1"} value={l.qtd} aria-label="Quantidade"
                      onChange={(e) => setCart((c) => c.map((x, j) => (j === i ? { ...x, qtd: Math.max(0, +e.target.value) } : x)))} className="w-24 rounded border border-slate-300 px-2 py-1 disabled:border-transparent disabled:bg-transparent" />
                    {l.prod.porKg && " kg"}
                  </td>
                  <td className="px-4">{brl(l.prod.precoVarejo)}</td><td className="px-4 font-medium">{brl(l.prod.precoVarejo * l.qtd)}</td>
                  <td className="px-4"><div className="flex justify-end gap-1">
                    <button title={editando === i ? "Concluir edição" : "Editar"} aria-label="Editar" onClick={() => setEditando(editando === i ? null : i)} className="rounded p-1.5 text-slate-500 hover:bg-slate-100">{editando === i ? <Check size={16} /> : <Pencil size={16} />}</button>
                    <button title="Excluir" aria-label="Excluir" onClick={() => setCart((c) => c.filter((_, j) => j !== i))} className="rounded p-1.5 text-slate-500 hover:bg-slate-100"><Trash2 size={16} /></button>
                  </div></td>
                </tr>
              ))}
              {!cart.length && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-500">Caixa livre. Leia um produto para começar.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <aside className="h-fit rounded-xl border border-slate-200 bg-white p-4">
        <p className="text-xs text-slate-500">Total da venda</p>
        <p className="mb-4 text-3xl font-semibold text-slate-900">{brl(total)}</p>
        <div className="mb-3 grid grid-cols-2 gap-2">
          {(["Dinheiro", "PIX", "Débito", "Crédito"] as Pgto[]).map((p) => (
            <button key={p} onClick={() => setPgto(p)} className={`rounded-lg border px-3 py-2 text-sm ${pgto === p ? "border-teal-700 bg-teal-50 font-medium text-teal-900" : "border-slate-300"}`}>{p}</button>
          ))}
        </div>
        {pgto === "Dinheiro" && <label className="mb-3 block text-sm">Valor recebido<input type="number" min="0" step="0.01" value={recebido} onChange={(e) => setRecebido(e.target.value)} className={`${inp} mt-1 w-full`} /><span className="text-xs text-slate-500">Troco: {brl(troco)}</span></label>}
        {pgto === "Crédito" && <label className="mb-3 block text-sm">Parcelas<select value={parcelas} onChange={(e) => setParcelas(+e.target.value)} className={`${inp} mt-1 w-full`}>{[1, 2, 3, 4, 5, 6, 10, 12].map((n) => <option key={n} value={n}>{n}x de {brl(total / n)}</option>)}</select></label>}
        {pgto === "PIX" && <p className="mb-3 text-xs text-slate-500">O QR Code do PIX dinâmico será gerado pela API bancária (mock nesta versão).</p>}
        <button disabled={emitindo || !cart.length} onClick={finalizar} className="flex w-full items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-3 text-sm font-medium text-white disabled:opacity-50">{emitindo && <Loader2 size={16} className="animate-spin" />} Finalizar e emitir NFC-e</button>
        <button onClick={novaVenda} className="mt-2 w-full rounded-lg border border-slate-300 px-4 py-2 text-sm">Cancelar venda</button>
      </aside>

      {pendentePeso && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-900/40 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-sm rounded-xl bg-white p-5 shadow-xl">
            <div className="mb-3 flex items-center justify-between"><h2 className="flex items-center gap-2 text-base font-semibold"><Scale size={18} /> Pesagem</h2><button aria-label="Fechar" onClick={() => setPendentePeso(null)}><X size={18} /></button></div>
            <p className="mb-2 text-sm">{pendentePeso.nome} · {brl(pendentePeso.precoVarejo)}/kg</p>
            <input autoFocus value={peso} onChange={(e) => setPeso(e.target.value)} onKeyDown={(e) => e.key === "Enter" && confirmarPeso()} placeholder="Peso em kg (ex.: 0,350)" className={`${inp} w-full`} />
            <div className="mt-4 flex justify-end gap-2"><button onClick={() => setPendentePeso(null)} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button><button onClick={confirmarPeso} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Adicionar</button></div>
          </div>
        </div>
      )}

      {recibo && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-900/40 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-sm rounded-xl bg-white p-5 text-center shadow-xl">
            <span className="mx-auto mb-2 grid size-10 place-items-center rounded-full bg-emerald-100 text-emerald-700"><Check /></span>
            <h2 className="text-base font-semibold">NFC-e autorizada</h2>
            <p className="text-sm text-slate-600">{brl(recibo.total)} · {recibo.pgto}{recibo.troco > 0 && ` · troco ${brl(recibo.troco)}`}</p>
            <p className="mt-2 break-all text-xs text-slate-400">Chave: {recibo.chave}<br />Protocolo: {recibo.protocolo} (ambiente simulado)</p>
            <button autoFocus onClick={novaVenda} className="mt-4 w-full rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Nova venda</button>
          </div>
        </div>
      )}
    </main>
  );
}

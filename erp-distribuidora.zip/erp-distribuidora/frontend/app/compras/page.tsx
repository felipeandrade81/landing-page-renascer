"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { Eye, Pencil, Trash2, Plus, FileUp, X, Check, Send, PackageCheck } from "lucide-react";
import { api, erroMsg } from "@/lib/api";

/* ───────── Tipos (dados vindos da API) ───────── */
type Status = "Rascunho" | "Pendente aprovação" | "Aprovado" | "Recebido" | "Cancelado";
type Item = { sku: string; qtd: number; custo: number };
type Pedido = { id: string; numero: number; fornecedor: string; status: Status; itens: Item[]; criadoEm: string; chave?: string };
type Produto = { id: string; sku: string; nome: string; estoque: number; custoMedio: number; reposicao: number; precoAtacado: number; precoVarejo: number };

const STATUS_API: Record<string, Status> = { RASCUNHO: "Rascunho", PENDENTE_APROVACAO: "Pendente aprovação", APROVADO: "Aprovado", RECEBIDO: "Recebido", CANCELADO: "Cancelado" };
const ACAO: Record<string, string> = { "Pendente aprovação": "submit", Aprovado: "approve", Cancelado: "cancel" };

const cor: Record<Status, string> = {
  Rascunho: "bg-slate-200 text-slate-700", "Pendente aprovação": "bg-amber-100 text-amber-800",
  Aprovado: "bg-sky-100 text-sky-800", Recebido: "bg-emerald-100 text-emerald-800", Cancelado: "bg-red-100 text-red-800",
};
const brl = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const total = (it: Item[]) => it.reduce((a, i) => a + i.qtd * i.custo, 0);
const margem = (preco: number, custo: number) => (preco ? ((preco - custo) / preco) * 100 : 0);

const pedidoSchema = z.object({
  fornecedor: z.string().min(1, "Escolha um fornecedor"),
  itens: z.array(z.object({ sku: z.string().min(1), qtd: z.number().positive(), custo: z.number().positive() })).min(1, "Adicione ao menos um item com quantidade e custo maiores que zero"),
});

type XmlNota = { chave: string; emitente: string; cnpj: string; numero: string; itens: (Item & { nome: string; cadastrado: boolean })[]; valor: number };

export default function ComprasPage() {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [fornecedores, setFornecedores] = useState<{ id: string; nome: string; cnpj: string }[]>([]);
  const [xmlTxt, setXmlTxt] = useState("");

  async function carregar() {
    try {
      const [f, pr, pe] = await Promise.all([api<any[]>("/suppliers?take=200"), api<any[]>("/products?take=200"), api<any[]>("/purchases")]);
      setFornecedores(f.map((s) => ({ id: s.id, nome: s.legalName, cnpj: s.cnpj })));
      setProdutos(pr.map((p) => ({
        id: p.id, sku: p.sku, nome: p.name, estoque: (p.batches ?? []).reduce((a: number, b: any) => a + Number(b.quantity), 0),
        custoMedio: Number(p.avgCost), reposicao: Number(p.replacementCost), precoVarejo: Number(p.retailPrice),
        precoAtacado: Number([...(p.priceTiers ?? [])].sort((a: any, b: any) => Number(a.minQty) - Number(b.minQty))[0]?.price ?? p.retailPrice), // 1ª faixa da tabela progressiva
      })));
      const sku = new Map<string, string>(pr.map((p) => [p.id, p.sku]));
      setPedidos(pe.map((p) => ({
        id: p.id, numero: p.number, fornecedor: p.supplier.legalName, status: STATUS_API[p.status], criadoEm: String(p.createdAt).slice(0, 10), chave: p.nfeXmlKey ?? undefined,
        itens: p.items.map((i: any) => ({ sku: sku.get(i.productId) ?? i.productId, qtd: Number(i.quantity), custo: Number(i.unitCost) })),
      })));
    } catch (e) { setMsg(erroMsg(e)); }
  }
  useEffect(() => { carregar(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const [modal, setModal] = useState<null | { mode: "novo" | "ver" | "editar" | "excluir"; id?: string }>(null);
  const [fornecedor, setFornecedor] = useState("");
  const [itens, setItens] = useState<Item[]>([{ sku: "", qtd: 1, custo: 0 }]);
  const [erro, setErro] = useState("");
  const [nota, setNota] = useState<XmlNota | null>(null);
  const [msg, setMsg] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const atual = pedidos.find((p) => p.id === modal?.id);
  const somenteLeitura = modal?.mode === "ver" || (modal?.mode === "editar" && (atual?.status === "Recebido" || atual?.status === "Cancelado"));
  const nomeProduto = (sku: string) => produtos.find((p) => p.sku === sku)?.nome ?? sku;
  const proxNumero = useMemo(() => Math.max(1000, ...pedidos.map((p) => p.numero)) + 1, [pedidos]);

  function abrir(mode: "novo" | "ver" | "editar" | "excluir", p?: Pedido) {
    setFornecedor(p?.fornecedor ?? ""); setItens(p ? p.itens.map((i) => ({ ...i })) : [{ sku: "", qtd: 1, custo: 0 }]); setErro(""); setModal({ mode, id: p?.id });
  }
  const fechar = () => { setModal(null); setErro(""); };
  async function mudar(id: string, status: Status) {
    try { await api(`/purchases/${id}/${ACAO[status]}`, { method: "POST" }); await carregar(); } catch (e) { setMsg(erroMsg(e)); }
  }

  async function salvar(enviar: boolean) {
    const r = pedidoSchema.safeParse({ fornecedor, itens });
    if (!r.success) return setErro(r.error.issues[0].message);
    const supplierId = fornecedores.find((f) => f.nome === fornecedor)?.id;
    const items = itens.map((i) => ({ productId: produtos.find((p) => p.sku === i.sku)?.id, quantity: i.qtd, unitCost: i.custo }));
    if (!supplierId || items.some((i) => !i.productId)) return setErro("Fornecedor ou produto inválido. Recarregue a página.");
    try {
      const editar = modal?.mode === "editar";
      const saved = await api<{ id: string }>(editar ? `/purchases/${modal?.id}` : "/purchases", { method: editar ? "PATCH" : "POST", body: { supplierId, items } });
      if (enviar && (editar ? atual?.status : "Rascunho") === "Rascunho") await api(`/purchases/${saved.id}/submit`, { method: "POST" });
      await carregar(); fechar(); // editar um pedido aprovado o devolve para aprovação (regra da API)
    } catch (e) { setErro(erroMsg(e)); }
  }

  /* Recebimento: a API dá entrada por lote, recalcula o custo médio e cria a conta a pagar */
  async function receber(p: Pedido) {
    try { await api(`/purchases/${p.id}/receive`, { method: "POST", body: {} }); await carregar(); setMsg(`Pedido ${p.numero} recebido: estoque e custo médio atualizados.`); }
    catch (e) { setMsg(erroMsg(e)); }
  }

  /* Importação do XML da NF-e de entrada */
  async function lerXml(file: File) {
    setMsg("");
    const txt = await file.text(); setXmlTxt(txt);
    const doc = new DOMParser().parseFromString(txt, "text/xml"); // só para a conferência; quem grava é a API
    const t = (el: Element | Document, tag: string) => el.getElementsByTagName(tag)[0]?.textContent ?? "";
    const inf = doc.getElementsByTagName("infNFe")[0];
    if (!inf) return setMsg("Arquivo inválido: não encontrei uma NF-e (tag infNFe).");
    const chave = (inf.getAttribute("Id") ?? "").replace("NFe", "");
    if (pedidos.some((p) => p.chave === chave)) return setMsg("Esta NF-e já foi importada.");
    const emit = doc.getElementsByTagName("emit")[0];
    const its = Array.from(doc.getElementsByTagName("det")).map((d) => {
      const sku = t(d, "cProd");
      return { sku, nome: t(d, "xProd"), qtd: parseFloat(t(d, "qCom")), custo: parseFloat(t(d, "vUnCom")), cadastrado: produtos.some((p) => p.sku === sku) };
    });
    setNota({ chave, emitente: t(emit, "xNome"), cnpj: t(emit, "CNPJ"), numero: t(inf, "nNF"), itens: its, valor: parseFloat(t(doc, "vNF")) || 0 });
  }
  async function confirmarXml() {
    if (!nota) return;
    try {
      const r = await api<{ ignored: string[] }>("/purchases/import-xml", { method: "POST", body: { xml: xmlTxt } });
      await carregar();
      setMsg(`NF-e ${nota.numero} importada e com entrada no estoque.${r.ignored?.length ? ` ${r.ignored.length} item(ns) sem cadastro foram ignorados.` : ""}`);
    } catch (e) { setMsg(erroMsg(e)); }
    setNota(null); // TODO: manifestação do destinatário (evento 210200) via SefazGateway
  }

  const inp = "w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm disabled:bg-slate-50";
  return (
    <main className="p-4 md:p-8">
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-semibold text-slate-900">Compras</h1><p className="text-sm text-slate-500">Pedidos, aprovação e entrada de mercadorias</p></div>
        <div className="flex gap-2">
          <input ref={fileRef} type="file" accept=".xml" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) lerXml(f); e.target.value = ""; }} />
          <button onClick={() => fileRef.current?.click()} className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"><FileUp size={16} /> Importar XML da NF-e</button>
          <button onClick={() => abrir("novo")} className="flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800"><Plus size={16} /> Novo pedido</button>
        </div>
      </header>
      {msg && <p className="mb-4 rounded-lg bg-teal-50 px-4 py-2 text-sm text-teal-900" role="status">{msg}</p>}

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="bg-slate-50 text-xs text-slate-500"><tr>{["Pedido", "Fornecedor", "Data", "Total", "Status", "Ações"].map((c) => <th key={c} className={`px-4 py-3 font-medium ${c === "Ações" ? "text-right" : ""}`}>{c}</th>)}</tr></thead>
          <tbody>
            {pedidos.map((p) => (
              <tr key={p.id} className="border-t border-slate-100">
                <td className="px-4 py-3 font-medium">#{p.numero}</td><td className="px-4">{p.fornecedor}</td>
                <td className="px-4">{p.criadoEm.split("-").reverse().join("/")}</td><td className="px-4">{brl(total(p.itens))}</td>
                <td className="px-4"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${cor[p.status]}`}>{p.status}</span></td>
                <td className="px-4">
                  <div className="flex items-center justify-end gap-1">
                    {p.status === "Rascunho" && <button onClick={() => mudar(p.id, "Pendente aprovação")} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-amber-800 hover:bg-amber-50"><Send size={14} /> Enviar</button>}
                    {p.status === "Pendente aprovação" && <button onClick={() => mudar(p.id, "Aprovado")} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-emerald-800 hover:bg-emerald-50"><Check size={14} /> Aprovar</button>}
                    {p.status === "Aprovado" && <button onClick={() => receber(p)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-teal-800 hover:bg-teal-50"><PackageCheck size={14} /> Receber</button>}
                    {(p.status === "Pendente aprovação" || p.status === "Aprovado") && <button onClick={() => mudar(p.id, "Cancelado")} className="rounded px-2 py-1 text-xs text-red-700 hover:bg-red-50">Cancelar</button>}
                    {([[Eye, "Visualizar", "ver"], [Pencil, "Editar", "editar"], [Trash2, "Excluir", "excluir"]] as const).map(([I, l, m]) => (
                      <button key={l} title={l} aria-label={l} onClick={() => abrir(m, p)} className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"><I size={16} /></button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
            {!pedidos.length && <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-500">Nenhum pedido ainda. Crie um pedido ou importe o XML de uma NF-e.</td></tr>}
          </tbody>
        </table>
      </div>

      <h2 className="mb-2 mt-8 text-base font-semibold">Custos e margem por canal</h2>
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="bg-slate-50 text-xs text-slate-500"><tr>{["Produto", "Estoque", "Custo médio", "Custo reposição", "Margem atacado", "Margem varejo"].map((c) => <th key={c} className="px-4 py-3 font-medium">{c}</th>)}</tr></thead>
          <tbody>{produtos.map((p) => (
            <tr key={p.sku} className="border-t border-slate-100"><td className="px-4 py-3">{p.nome}<span className="block text-xs text-slate-400">{p.sku}</span></td><td className="px-4">{p.estoque}</td>
              <td className="px-4">{brl(p.custoMedio)}</td><td className="px-4">{brl(p.reposicao)}</td>
              <td className="px-4">{margem(p.precoAtacado, p.custoMedio).toFixed(1)}%</td><td className="px-4">{margem(p.precoVarejo, p.custoMedio).toFixed(1)}%</td></tr>
          ))}</tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-slate-900/40 p-4" onClick={fechar} role="dialog" aria-modal="true">
          <div className="w-full max-w-2xl rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-semibold">{{ novo: "Novo pedido de compra", ver: `Pedido #${atual?.numero}`, editar: `Editar pedido #${atual?.numero}`, excluir: "Excluir pedido" }[modal.mode]}</h2>
              <button onClick={fechar} aria-label="Fechar" className="rounded p-1 hover:bg-slate-100"><X size={18} /></button>
            </div>
            {modal.mode === "excluir" ? (
              <>
                <p className="text-sm">Excluir o pedido <strong>#{atual?.numero}</strong>?{atual?.status === "Recebido" && " A entrada de estoque já feita não será desfeita."}</p>
                <div className="mt-5 flex justify-end gap-2">
                  <button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
                  <button onClick={async () => { try { await api(`/purchases/${modal.id}`, { method: "DELETE" }); await carregar(); } catch (e) { setMsg(erroMsg(e)); } fechar(); }} className="rounded-lg bg-red-600 px-4 py-2 text-sm text-white">Excluir</button>
                </div>
              </>
            ) : (
              <div className="space-y-3">
                {modal.mode === "editar" && somenteLeitura && <p className="rounded-lg bg-slate-100 px-3 py-2 text-xs">Pedidos {atual?.status.toLowerCase()}s não podem ser alterados.</p>}
                {modal.mode === "editar" && atual?.status === "Aprovado" && <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-900">Ao salvar, o pedido volta para aprovação.</p>}
                <label className="block text-sm">Fornecedor
                  <select disabled={somenteLeitura} value={fornecedor} onChange={(e) => setFornecedor(e.target.value)} className={`mt-1 ${inp}`}>
                    <option value="">Selecione…</option>{fornecedores.map((f) => <option key={f.cnpj}>{f.nome}</option>)}
                  </select>
                </label>
                <div className="space-y-2">
                  {itens.map((it, i) => (
                    <div key={i} className="grid grid-cols-[1fr_80px_100px_32px] items-center gap-2">
                      <select disabled={somenteLeitura} value={it.sku} aria-label="Produto" onChange={(e) => setItens((l) => l.map((x, j) => (j === i ? { ...x, sku: e.target.value, custo: x.custo || (produtos.find((p) => p.sku === e.target.value)?.reposicao ?? 0) } : x)))} className={inp}>
                        <option value="">Produto…</option>{produtos.map((p) => <option key={p.sku} value={p.sku}>{p.nome}</option>)}
                      </select>
                      <input disabled={somenteLeitura} type="number" min="0" aria-label="Quantidade" value={it.qtd} onChange={(e) => setItens((l) => l.map((x, j) => (j === i ? { ...x, qtd: +e.target.value } : x)))} className={inp} />
                      <input disabled={somenteLeitura} type="number" min="0" step="0.01" aria-label="Custo unitário" value={it.custo} onChange={(e) => setItens((l) => l.map((x, j) => (j === i ? { ...x, custo: +e.target.value } : x)))} className={inp} />
                      {!somenteLeitura && <button onClick={() => setItens((l) => l.filter((_, j) => j !== i))} aria-label="Remover item" className="rounded p-1 text-slate-500 hover:bg-slate-100"><Trash2 size={16} /></button>}
                    </div>
                  ))}
                  {!somenteLeitura && <button onClick={() => setItens((l) => [...l, { sku: "", qtd: 1, custo: 0 }])} className="text-sm text-teal-800">+ Adicionar item</button>}
                </div>
                <p className="text-right text-sm">Total: <strong>{brl(total(itens))}</strong></p>
                {erro && <p className="text-sm text-red-600">{erro}</p>}
                <div className="flex justify-end gap-2 pt-1">
                  <button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">{somenteLeitura ? "Fechar" : "Cancelar"}</button>
                  {!somenteLeitura && <>
                    <button onClick={() => salvar(false)} className="rounded-lg border border-teal-700 px-4 py-2 text-sm text-teal-800">Salvar</button>
                    <button onClick={() => salvar(true)} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Salvar e enviar para aprovação</button>
                  </>}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {nota && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-900/40 p-4" onClick={() => setNota(null)} role="dialog" aria-modal="true">
          <div className="w-full max-w-xl rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-1 text-base font-semibold">Conferir NF-e {nota.numero}</h2>
            <p className="text-sm text-slate-600">{nota.emitente} · {brl(nota.valor)}</p>
            <p className="mb-3 break-all text-xs text-slate-400">Chave: {nota.chave}</p>
            <ul className="divide-y divide-slate-100 text-sm">
              {nota.itens.map((i) => (
                <li key={i.sku} className="flex items-center justify-between py-2">
                  <span>{i.nome}<span className="block text-xs text-slate-400">{i.qtd} × {brl(i.custo)}</span></span>
                  <span className={`rounded-full px-2 py-0.5 text-xs ${i.cadastrado ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}>{i.cadastrado ? "Cadastrado" : "Sem cadastro"}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setNota(null)} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
              <button onClick={confirmarXml} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Dar entrada no estoque</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

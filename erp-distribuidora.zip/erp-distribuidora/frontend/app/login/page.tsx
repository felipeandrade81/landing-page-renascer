"use client";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { erroMsg } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState(""); const [senha, setSenha] = useState("");
  const [erro, setErro] = useState(""); const [enviando, setEnviando] = useState(false);

  async function entrar(e: React.FormEvent) {
    e.preventDefault(); setErro(""); setEnviando(true);
    try { await login(email.trim(), senha); } // o layout redireciona após o login
    catch (err) { setErro(erroMsg(err)); }
    finally { setEnviando(false); }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 p-4">
      <form onSubmit={entrar} className="w-full max-w-sm space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-xl font-semibold text-teal-800">Distribui<span className="text-amber-600">ERP</span></h1>
        <p className="text-sm text-slate-500">Entre com seu e-mail e senha</p>
        <label className="block text-sm">E-mail
          <input type="email" required autoFocus autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2" />
        </label>
        <label className="block text-sm">Senha
          <input type="password" required autoComplete="current-password" value={senha} onChange={(e) => setSenha(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2" />
        </label>
        {erro && <p className="text-sm text-red-600" role="alert">{erro}</p>}
        <button disabled={enviando} className="flex w-full items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800 disabled:opacity-60">
          {enviando && <Loader2 size={16} className="animate-spin" />} Entrar
        </button>
      </form>
    </main>
  );
}

"use client";
import { useMemo, useRef, useState } from "react";
import { z } from "zod";
import { Eye, Pencil, Trash2, FileUp, Zap, Check, X } from "lucide-react";
import { brl } from "@/lib/mock";

/* ───────── Tipos e dados mock (trocar por API /api/finance/*) ───────── */
type Titulo = { id: string; desc: string; valor: number; venc: string; tipo: "Receber" | "Pagar"; status: "Pendente" | "Pago" };
type Lanc = { id: string; fitid: string; data: string; valor: number; memo: string; origem: "OFX" | "PIX"; matchId?: string; status: "Pendente" | "Conciliado" };
type Adq = { id: string; nome: string; debito: number; credito: number; parcelado: number; antecip: number; diasDebito: number; diasCredito: number };

const titulosIni: Titulo[] = [
  { id: "t1", desc: "Mercadinho Boa Vista – Venda 2051", valor: 9320.5, venc: "2026-09-30", tipo: "Receber", status: "Pendente" },
  { id: "t2", desc: "Restaurante Sabor do Mar – Venda 2050", valor: 8160, venc: "2026-10-10", tipo: "Receber", status: "Pendente" },
  { id: "t3", desc: "NF 48210 – Laticínios Vale", valor: 18450, venc: "2026-10-05", tipo: "Pagar", status: "Pendente" },
];
const adqIni: Adq[] = [
  { id: "a1", nome: "Stone", debito: 1.19, credito: 2.99, parcelado: 3.49, antecip: 1.99, diasDebito: 1, diasCredito: 30 },
  { id: "a2", nome: "PagBank", debito: 1.39, credito: 3.19, parcelado: 3.89, antecip: 2.19, diasDebito: 1, diasCredito: 30 },
  { id: "a3", nome: "Mercado Pago", debito: 1.29, credito: 3.05, parcelado: 3.79, antecip: 2.09, diasDebito: 1, diasCredito: 14 },
];
const adqSchema = z.object(Object.fromEntries(["debito", "credito", "parcelado", "antecip"].map((k) => [k, z.coerce.number().min(0, "Mínimo 0").max(30, "Máximo 30%")])));

const dias = (a: string, b: string) => Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 864e5;
const dataBR = (iso: string) => iso.split("-").reverse().join("/");

/** Parser OFX (SGML/XML simples): extrai os blocos STMTTRN. */
function lerOfx(txt: string): Omit<Lanc, "id" | "status" | "origem">[] {
  const tag = (b: string, t: string) => b.match(new RegExp(`<${t}>([^<\\r\\n]*)`, "i"))?.[1].trim() ?? "";
  return (txt.match(/<STMTTRN>[\s\S]*?(?=<\/STMTTRN>|<STMTTRN>|<\/BANKTRANLIST>)/gi) ?? []).map((b) => {
    const d = tag(b, "DTPOSTED");
    return { fitid: tag(b, "FITID"), data: `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`, valor: parseFloat(tag(b, "TRNAMT").replace(",", ".")), memo: tag(b, "MEMO") || tag(b, "NAME") };
  }).filter((l) => l.fitid && !isNaN(l.valor));
}

export default function FinanceiroPage() {
  const [aba, setAba] = useState<"conc" | "cartoes">("conc");
  const [titulos, setTitulos] = useState(titulosIni);
  const [lancs, setLancs] = useState<Lanc[]>([]);
  const [adqs, setAdqs] = useState(adqIni);
  const [msg, setMsg] = useState("");
  const [modal, setModal] = useState<null | { kind: "lanc" | "adq"; mode: "ver" | "editar" | "excluir"; id: string }>(null);
  const [matchSel, setMatchSel] = useState(""); const [erros, setErros] = useState<Record<string, string>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  // simulador / recebíveis
  const [sim, setSim] = useState({ adq: "a1", valor: 1000, modo: "credito", parcelas: 1, antecipar: false });
  const [recebiveis, setRecebiveis] = useState([
    { id: "r1", desc: "Crédito 3x – Stone (parcela 1/3)", bruto: 1200, data: "2026-10-20", antecipar: false, adq: "a1" },
    { id: "r2", desc: "Crédito à vista – PagBank", bruto: 2300, data: "2026-10-28", antecipar: false, adq: "a2" },
    { id: "r3", desc: "Débito – Mercado Pago", bruto: 640, data: "2026-10-03", antecipar: false, adq: "a3" },
  ]);

  const sugerir = (l: Omit<Lanc, "id" | "status" | "origem">, usados: Set<string>) =>
    titulos.find((t) => t.status === "Pendente" && !usados.has(t.id) && Math.abs(Math.abs(l.valor) - t.valor) < 0.01 && (l.valor > 0) === (t.tipo === "Receber") && dias(l.data, t.venc) <= 5)?.id;

  async function importar(f: File) {
    setMsg("");
    if (!/\.ofx$/i.test(f.name)) return setMsg("CNAB 240/400: o processamento de retorno é feito no backend (o layout varia por banco). Endpoint reservado: POST /api/finance/cnab.");
    const itens = lerOfx(await f.text());
    if (!itens.length) return setMsg("Nenhuma transação encontrada no OFX.");
    const ja = new Set(lancs.map((l) => l.fitid)), usados = new Set(lancs.map((l) => l.matchId).filter(Boolean) as string[]);
    const novos = itens.filter((i) => !ja.has(i.fitid)).map((i) => { const m = sugerir(i, usados); if (m) usados.add(m); return { ...i, id: crypto.randomUUID(), origem: "OFX" as const, matchId: m, status: "Pendente" as const }; });
    setLancs((l) => [...novos, ...l]); setMsg(`${novos.length} lançamento(s) importado(s); ${itens.length - novos.length} duplicado(s) ignorado(s).`);
  }

  /** Simula o payload do webhook PIX (em produção: POST /api/webhooks/pix validado por assinatura/mTLS). */
  function simularPix() {
    const t = titulos.find((x) => x.tipo === "Receber" && x.status === "Pendente");
    if (!t) return setMsg("Não há títulos a receber em aberto para simular.");
    const l: Lanc = { id: crypto.randomUUID(), fitid: `E${Date.now()}`, data: new Date().toISOString().slice(0, 10), valor: t.valor, memo: `PIX recebido – ${t.desc}`, origem: "PIX", matchId: t.id, status: "Conciliado" };
    setLancs((x) => [l, ...x]); setTitulos((ts) => ts.map((x) => (x.id === t.id ? { ...x, status: "Pago" } : x))); setMsg(`Webhook PIX recebido e conciliado automaticamente: ${t.desc}.`);
  }
  const conciliar = (l: Lanc, matchId = l.matchId) => {
    if (!matchId) return setMsg("Escolha antes um título para conciliar (Editar).");
    setLancs((x) => x.map((i) => (i.id === l.id ? { ...i, matchId, status: "Conciliado" } : i))); setTitulos((ts) => ts.map((t) => (t.id === matchId ? { ...t, status: "Pago" } : t))); setMsg("Lançamento conciliado.");
  };

  /* Cartões */
  const taxa = (a: Adq, modo: string, p: number) => (modo === "debito" ? a.debito : p > 1 ? a.parcelado : a.credito);
  const calc = (a: Adq, valor: number, modo: string, p: number, antecipar: boolean) => {
    const prazo = modo === "debito" ? a.diasDebito : a.diasCredito;
    const mdr = valor * taxa(a, modo, p) / 100, ant = antecipar ? valor * (a.antecip / 100) * (Math.max(prazo - 1, 0) / 30) : 0;
    return { mdr, ant, liquido: valor - mdr - ant, prazo: antecipar ? 1 : prazo };
  };
  const s = calc(adqs.find((a) => a.id === sim.adq)!, sim.valor, sim.modo, sim.parcelas, sim.antecipar);
  const prevDep = useMemo(() => recebiveis.reduce((acc, r) => { const a = adqs.find((x) => x.id === r.adq)!; return acc + calc(a, r.bruto, /Débito/.test(r.desc) ? "debito" : /3x/.test(r.desc) ? "credito" : "credito", /3x/.test(r.desc) ? 3 : 1, r.antecipar).liquido; }, 0), [recebiveis, adqs]);

  function salvarAdq(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const r = adqSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!r.success) return setErros(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message])));
    setAdqs((l) => l.map((a) => (a.id === modal?.id ? { ...a, ...(r.data as any) } : a))); setModal(null); setErros({}); // TODO: PATCH /api/acquirers/:id
  }
  const fechar = () => { setModal(null); setErros({}); };
  const lAtual = modal?.kind === "lanc" ? lancs.find((l) => l.id === modal.id) : undefined;
  const aAtual = modal?.kind === "adq" ? adqs.find((a) => a.id === modal.id) : undefined;
  const inp = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50";
  const th = (cols: string[]) => <thead className="bg-slate-50 text-xs text-slate-500"><tr>{cols.map((c) => <th key={c} className={`px-4 py-3 font-medium ${c === "Ações" ? "text-right" : ""}`}>{c}</th>)}</tr></thead>;
  const Acoes = ({ kind, id, ex = true }: { kind: "lanc" | "adq"; id: string; ex?: boolean }) => (
    <div className="flex justify-end gap-1">{([[Eye, "Visualizar", "ver"], [Pencil, "Editar", "editar"], ...(ex ? [[Trash2, "Excluir", "excluir"]] : [])] as const).map(([I, l, m]: any) => (
      <button key={l} title={l} aria-label={l} onClick={() => { setMatchSel(lancs.find((x) => x.id === id)?.matchId ?? ""); setModal({ kind, mode: m, id }); }} className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"><I size={16} /></button>))}</div>
  );

  return (
    <main className="p-4 md:p-8">
      <h1 className="text-2xl font-semibold text-slate-900">Financeiro</h1>
      <div className="my-4 flex gap-1 rounded-lg bg-slate-100 p-0.5 text-sm w-fit">
        {([["conc", "Conciliação bancária"], ["cartoes", "Cartões e adquirentes"]] as const).map(([k, l]) => <button key={k} onClick={() => setAba(k)} className={`rounded-md px-4 py-1.5 ${aba === k ? "bg-white font-medium shadow-sm" : "text-slate-500"}`}>{l}</button>)}
      </div>
      {msg && <p className="mb-4 rounded-lg bg-teal-50 px-4 py-2 text-sm text-teal-900" role="status">{msg}</p>}

      {aba === "conc" ? (
        <>
          <div className="mb-4 flex flex-wrap gap-2">
            <input ref={fileRef} type="file" accept=".ofx,.ret,.rem,.cnab,.txt" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) importar(f); e.target.value = ""; }} />
            <button onClick={() => fileRef.current?.click()} className="flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white"><FileUp size={16} /> Importar extrato (OFX/CNAB)</button>
            <button onClick={simularPix} className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm"><Zap size={16} /> Simular webhook PIX</button>
          </div>
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table className="w-full min-w-[820px] text-left text-sm">
            {th(["Data", "Descrição", "Valor", "Origem", "Título sugerido", "Status", "Ações"])}
            <tbody>
              {lancs.map((l) => { const t = titulos.find((x) => x.id === l.matchId); return (
                <tr key={l.id} className="border-t border-slate-100">
                  <td className="px-4 py-3">{dataBR(l.data)}</td><td className="px-4">{l.memo}<span className="block text-xs text-slate-400">{l.fitid}</span></td>
                  <td className={`px-4 ${l.valor < 0 ? "text-red-700" : "text-emerald-700"}`}>{brl(l.valor)}</td><td className="px-4">{l.origem}</td>
                  <td className="px-4 text-xs">{t ? t.desc : <span className="text-slate-400">sem correspondência</span>}</td>
                  <td className="px-4"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${l.status === "Conciliado" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>{l.status}</span></td>
                  <td className="px-4"><div className="flex items-center justify-end gap-1">{l.status === "Pendente" && l.matchId && <button onClick={() => conciliar(l)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-emerald-800 hover:bg-emerald-50"><Check size={14} /> Conciliar</button>}<Acoes kind="lanc" id={l.id} /></div></td>
                </tr>); })}
              {!lancs.length && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-500">Importe um extrato OFX ou simule um PIX para ver as sugestões de conciliação.</td></tr>}
            </tbody></table></div>
          <p className="mt-2 text-xs text-slate-500">Títulos em aberto: {titulos.filter((t) => t.status === "Pendente").length} · Regra de sugestão: mesmo valor, mesmo sentido e data até 5 dias do vencimento.</p>
        </>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white lg:col-span-2"><table className="w-full min-w-[720px] text-left text-sm">
            {th(["Adquirente", "Débito", "Crédito à vista", "Parcelado", "Antecipação (a.m.)", "Ações"])}
            <tbody>{adqs.map((a) => <tr key={a.id} className="border-t border-slate-100"><td className="px-4 py-3 font-medium">{a.nome}</td><td className="px-4">{a.debito}%</td><td className="px-4">{a.credito}%</td><td className="px-4">{a.parcelado}%</td><td className="px-4">{a.antecip}%</td><td className="px-4"><Acoes kind="adq" id={a.id} ex={false} /></td></tr>)}</tbody></table></div>

          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-3 text-sm font-semibold">Simulador de venda no cartão</h2>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <label>Adquirente<select value={sim.adq} onChange={(e) => setSim({ ...sim, adq: e.target.value })} className={inp}>{adqs.map((a) => <option key={a.id} value={a.id}>{a.nome}</option>)}</select></label>
              <label>Valor (R$)<input type="number" min="0" value={sim.valor} onChange={(e) => setSim({ ...sim, valor: +e.target.value })} className={inp} /></label>
              <label>Modalidade<select value={sim.modo} onChange={(e) => setSim({ ...sim, modo: e.target.value, parcelas: 1 })} className={inp}><option value="credito">Crédito</option><option value="debito">Débito</option></select></label>
              <label>Parcelas<select disabled={sim.modo === "debito"} value={sim.parcelas} onChange={(e) => setSim({ ...sim, parcelas: +e.target.value })} className={inp}>{[1, 2, 3, 6, 12].map((n) => <option key={n}>{n}</option>)}</select></label>
              <label className="col-span-2 flex items-center gap-2"><input type="checkbox" checked={sim.antecipar} onChange={(e) => setSim({ ...sim, antecipar: e.target.checked })} /> Antecipar recebimento</label>
            </div>
            <dl className="mt-3 grid grid-cols-3 gap-2 rounded-lg bg-slate-50 p-3 text-center text-xs">
              <div><dt className="text-slate-500">Taxa</dt><dd className="text-sm font-semibold">{brl(s.mdr)}</dd></div>
              <div><dt className="text-slate-500">Antecipação</dt><dd className="text-sm font-semibold">{brl(s.ant)}</dd></div>
              <div><dt className="text-slate-500">Líquido em {s.prazo}d</dt><dd className="text-sm font-semibold text-emerald-700">{brl(s.liquido)}</dd></div>
            </dl>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <h2 className="mb-1 text-sm font-semibold">Previsão de depósitos na conta</h2>
            <p className="mb-3 text-xs text-slate-500">Marque os recebíveis que deseja antecipar.</p>
            <ul className="divide-y divide-slate-100 text-sm">{recebiveis.map((r) => <li key={r.id} className="flex items-center justify-between gap-2 py-2">
              <label className="flex items-center gap-2"><input type="checkbox" checked={r.antecipar} onChange={() => setRecebiveis((l) => l.map((x) => (x.id === r.id ? { ...x, antecipar: !x.antecipar } : x)))} /><span>{r.desc}<span className="block text-xs text-slate-400">{r.antecipar ? "antecipado: amanhã" : dataBR(r.data)}</span></span></label>
              <span>{brl(r.bruto)}</span></li>)}</ul>
            <p className="mt-3 text-right text-sm">Líquido previsto: <strong>{brl(prevDep)}</strong></p>
          </div>
        </div>
      )}

      {modal && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-slate-900/40 p-4" onClick={fechar} role="dialog" aria-modal="true">
          <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between"><h2 className="text-base font-semibold">{modal.kind === "adq" ? aAtual?.nome : "Lançamento bancário"}</h2><button onClick={fechar} aria-label="Fechar" className="rounded p-1 hover:bg-slate-100"><X size={18} /></button></div>
            {modal.kind === "lanc" && lAtual && (modal.mode === "excluir" ? (<>
              <p className="text-sm">Excluir o lançamento <strong>{lAtual.memo}</strong>? Se estiver conciliado, o título volta para Pendente.</p>
              <div className="mt-5 flex justify-end gap-2"><button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
                <button onClick={() => { if (lAtual.status === "Conciliado") setTitulos((ts) => ts.map((t) => (t.id === lAtual.matchId ? { ...t, status: "Pendente" } : t))); setLancs((l) => l.filter((x) => x.id !== lAtual.id)); fechar(); }} className="rounded-lg bg-red-600 px-4 py-2 text-sm text-white">Excluir</button></div></>
            ) : (<>
              <dl className="space-y-1 text-sm"><div>Data: {dataBR(lAtual.data)}</div><div>Valor: {brl(lAtual.valor)}</div><div>Histórico: {lAtual.memo}</div><div>ID: {lAtual.fitid}</div></dl>
              <label className="mt-3 block text-sm">Título correspondente
                <select disabled={modal.mode === "ver" || lAtual.status === "Conciliado"} value={matchSel} onChange={(e) => setMatchSel(e.target.value)} className={inp}><option value="">Nenhum</option>{titulos.filter((t) => t.status === "Pendente" || t.id === lAtual.matchId).map((t) => <option key={t.id} value={t.id}>{t.desc} · {brl(t.valor)}</option>)}</select></label>
              <div className="mt-5 flex justify-end gap-2"><button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">{modal.mode === "ver" ? "Fechar" : "Cancelar"}</button>
                {modal.mode === "editar" && lAtual.status === "Pendente" && <button onClick={() => { setLancs((l) => l.map((x) => (x.id === lAtual.id ? { ...x, matchId: matchSel || undefined } : x))); fechar(); }} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Salvar</button>}</div></>))}
            {modal.kind === "adq" && aAtual && (
              <form onSubmit={salvarAdq} className="grid grid-cols-2 gap-3 text-sm" key={aAtual.id + modal.mode}>
                {([["debito", "Débito (%)"], ["credito", "Crédito à vista (%)"], ["parcelado", "Parcelado (%)"], ["antecip", "Antecipação a.m. (%)"]] as const).map(([k, l]) => <label key={k}>{l}<input name={k} type="number" step="0.01" defaultValue={aAtual[k]} disabled={modal.mode === "ver"} className={inp} />{erros[k] && <span className="text-xs text-red-600">{erros[k]}</span>}</label>)}
                <div className="col-span-2 flex justify-end gap-2 pt-2"><button type="button" onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">{modal.mode === "ver" ? "Fechar" : "Cancelar"}</button>{modal.mode === "editar" && <button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Salvar taxas</button>}</div>
              </form>)}
          </div>
        </div>
      )}
    </main>
  );
}

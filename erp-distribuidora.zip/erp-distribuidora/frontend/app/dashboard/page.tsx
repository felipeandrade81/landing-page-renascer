"use client";
import { useMemo, useState } from "react";
import { z } from "zod";
import {
  Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Boxes, TriangleAlert, CalendarClock, Wallet, Eye, Pencil, Trash2, Download, X } from "lucide-react";

/* ───────── Tipos e dados mock (trocar por fetch na API /api/dashboard) ───────── */
type Period = "diario" | "semanal" | "mensal";
type Lote = { id: string; produto: string; lote: string; validade: string; qtd: number; status: "Vencendo" | "Crítico" | "OK" };
type Conta = { id: string; descricao: string; tipo: "Pagar" | "Receber"; valor: number; vencimento: string; status: "Pendente" | "Pago" | "Atrasado" };

const movimentacao: Record<Period, { p: string; entrada: number; saida: number }[]> = {
  diario: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((p, i) => ({ p, entrada: [320, 180, 410, 90, 260, 140][i], saida: [280, 300, 350, 220, 390, 310][i] })),
  semanal: ["S1", "S2", "S3", "S4"].map((p, i) => ({ p, entrada: [1900, 2300, 1700, 2600][i], saida: [1750, 2100, 2000, 2350][i] })),
  mensal: ["Mai", "Jun", "Jul", "Ago", "Set", "Out"].map((p, i) => ({ p, entrada: [8200, 9100, 7800, 10400, 9600, 11200][i], saida: [7600, 8800, 8100, 9700, 9900, 10300][i] })),
};
const receitaCanal = ["Mai", "Jun", "Jul", "Ago", "Set", "Out"].map((m, i) => ({ m, atacado: [182, 205, 198, 240, 226, 258][i], varejo: [64, 71, 69, 82, 88, 95][i] }));
const fluxoCaixa = ["Sem 1", "Sem 2", "Sem 3", "Sem 4", "Sem 5", "Sem 6"].map((s, i) => ({ s, receber: [88, 74, 102, 91, 110, 96][i], pagar: [70, 82, 77, 85, 69, 90][i] }));

const lotesIniciais: Lote[] = [
  { id: "1", produto: "Leite UHT Integral 1L (cx 12)", lote: "L2409-A", validade: "2026-10-12", qtd: 140, status: "Crítico" },
  { id: "2", produto: "Iogurte Natural 170g (cx 24)", lote: "L2409-C", validade: "2026-10-20", qtd: 62, status: "Vencendo" },
  { id: "3", produto: "Suco de Uva Integral 1L (cx 6)", lote: "L2408-F", validade: "2026-11-05", qtd: 210, status: "Vencendo" },
  { id: "4", produto: "Biscoito Recheado 130g (cx 40)", lote: "L2410-B", validade: "2027-01-18", qtd: 330, status: "OK" },
];
const contasIniciais: Conta[] = [
  { id: "1", descricao: "NF 48210 – Laticínios Vale", tipo: "Pagar", valor: 18450, vencimento: "2026-10-05", status: "Pendente" },
  { id: "2", descricao: "Mercadinho Boa Vista – Pedido 1042", tipo: "Receber", valor: 9320.5, vencimento: "2026-09-28", status: "Atrasado" },
  { id: "3", descricao: "Repasse Stone – crédito 3x", tipo: "Receber", valor: 4210.9, vencimento: "2026-10-08", status: "Pendente" },
  { id: "4", descricao: "Frete – Transportes Norte", tipo: "Pagar", valor: 2780, vencimento: "2026-09-30", status: "Pago" },
];

/* ───────── Helpers de UI ───────── */
const brl = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const dataBR = (iso: string) => iso.split("-").reverse().join("/");
const badgeCor: Record<string, string> = {
  Pendente: "bg-amber-100 text-amber-800", Pago: "bg-emerald-100 text-emerald-800", Atrasado: "bg-red-100 text-red-800",
  Crítico: "bg-red-100 text-red-800", Vencendo: "bg-amber-100 text-amber-800", OK: "bg-emerald-100 text-emerald-800",
};
const Badge = ({ s }: { s: string }) => <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${badgeCor[s]}`}>{s}</span>;

function Modal({ titulo, onClose, children }: { titulo: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-900/40 p-4" role="dialog" aria-modal="true" onClick={onClose}>
      <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900">{titulo}</h3>
          <button onClick={onClose} aria-label="Fechar" className="rounded p-1 hover:bg-slate-100"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

const Acoes = ({ onView, onEdit, onDelete }: { onView: () => void; onEdit: () => void; onDelete: () => void }) => (
  <div className="flex justify-end gap-1">
    {[[Eye, "Visualizar", onView], [Pencil, "Editar", onEdit], [Trash2, "Excluir", onDelete]].map(([I, l, fn]: any) => (
      <button key={l} onClick={fn} title={l} aria-label={l} className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"><I size={16} /></button>
    ))}
  </div>
);

/* ───────── Validação (Zod) ───────── */
const loteSchema = z.object({
  produto: z.string().min(3, "Informe o produto"),
  lote: z.string().min(2, "Informe o lote"),
  validade: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data inválida"),
  qtd: z.coerce.number().int().min(0, "Quantidade não pode ser negativa"),
});
const contaSchema = z.object({
  descricao: z.string().min(3, "Informe a descrição"),
  valor: z.coerce.number().positive("Valor deve ser maior que zero"),
  vencimento: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data inválida"),
  status: z.enum(["Pendente", "Pago", "Atrasado"]),
});

/* ───────── Página ───────── */
export default function DashboardPage() {
  const [periodo, setPeriodo] = useState<Period>("mensal");
  const [lotes, setLotes] = useState(lotesIniciais);
  const [contas, setContas] = useState(contasIniciais);
  const [modal, setModal] = useState<null | { kind: "lote" | "conta"; mode: "ver" | "editar" | "excluir"; id: string }>(null);
  const [erros, setErros] = useState<Record<string, string>>({});

  const totalItens = 18432, abaixoMin = 23, criticos = 7;
  const aReceber = useMemo(() => contas.filter((c) => c.tipo === "Receber" && c.status !== "Pago").reduce((a, c) => a + c.valor, 0), [contas]);
  const aPagar = useMemo(() => contas.filter((c) => c.tipo === "Pagar" && c.status !== "Pago").reduce((a, c) => a + c.valor, 0), [contas]);
  const inadimplencia = useMemo(() => {
    const rec = contas.filter((c) => c.tipo === "Receber");
    const atras = rec.filter((c) => c.status === "Atrasado").reduce((a, c) => a + c.valor, 0);
    const total = rec.reduce((a, c) => a + c.valor, 0);
    return total ? (atras / total) * 100 : 0;
  }, [contas]);

  function exportarCSV() {
    const linhas = [["Descrição", "Tipo", "Valor", "Vencimento", "Status"], ...contas.map((c) => [c.descricao, c.tipo, c.valor, c.vencimento, c.status])];
    const blob = new Blob([linhas.map((l) => l.join(";")).join("\n")], { type: "text/csv;charset=utf-8" });
    const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: "contas.csv" });
    a.click(); URL.revokeObjectURL(a.href);
  }

  function salvar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!modal) return;
    const dados = Object.fromEntries(new FormData(e.currentTarget));
    const r = (modal.kind === "lote" ? loteSchema : contaSchema).safeParse(dados);
    if (!r.success) {
      setErros(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message])));
      return;
    }
    if (modal.kind === "lote") setLotes((l) => l.map((x) => (x.id === modal.id ? { ...x, ...(r.data as any) } : x)));
    else setContas((l) => l.map((x) => (x.id === modal.id ? { ...x, ...(r.data as any) } : x)));
    fechar(); // TODO: PATCH /api/lotes/:id ou /api/financeiro/:id
  }
  const fechar = () => { setModal(null); setErros({}); };
  const confirmarExclusao = () => {
    if (!modal) return;
    if (modal.kind === "lote") setLotes((l) => l.filter((x) => x.id !== modal.id));
    else setContas((l) => l.filter((x) => x.id !== modal.id));
    fechar(); // TODO: DELETE na API
  };

  const alvo: any = modal && (modal.kind === "lote" ? lotes : contas).find((x) => x.id === modal.id);
  const campos: [string, string, string][] = modal?.kind === "lote"
    ? [["produto", "Produto", "text"], ["lote", "Lote", "text"], ["validade", "Validade", "date"], ["qtd", "Quantidade", "number"]]
    : [["descricao", "Descrição", "text"], ["valor", "Valor (R$)", "number"], ["vencimento", "Vencimento", "date"]];

  return (
    <main className="min-h-screen bg-slate-50 p-4 text-slate-800 md:p-8">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Visão geral</h1>
          <p className="text-sm text-slate-500">Estoque, movimentação e financeiro em tempo real</p>
        </div>
        <button onClick={exportarCSV} className="flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800">
          <Download size={16} /> Exportar contas (CSV)
        </button>
      </header>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { l: "Itens em estoque", v: totalItens.toLocaleString("pt-BR"), I: Boxes },
          { l: "Abaixo do mínimo", v: `${abaixoMin} produtos (${criticos} críticos)`, I: TriangleAlert },
          { l: "A receber", v: brl(aReceber), I: Wallet },
          { l: "A pagar", v: brl(aPagar), I: CalendarClock },
        ].map(({ l, v, I }) => (
          <div key={l} className="rounded-xl border border-slate-200 bg-white p-4">
            <I size={18} className="text-teal-700" />
            <p className="mt-2 text-xs text-slate-500">{l}</p>
            <p className="text-lg font-semibold text-slate-900">{v}</p>
          </div>
        ))}
      </section>
      <p className="mt-2 text-xs text-slate-500">Inadimplência atual: <strong>{inadimplencia.toFixed(1)}%</strong> das contas a receber.</p>

      <section className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold">Entrada × saída de mercadorias</h2>
            <div className="flex rounded-lg bg-slate-100 p-0.5 text-xs">
              {(["diario", "semanal", "mensal"] as Period[]).map((p) => (
                <button key={p} onClick={() => setPeriodo(p)} className={`rounded-md px-3 py-1 capitalize ${periodo === p ? "bg-white font-medium shadow-sm" : "text-slate-500"}`}>{p === "diario" ? "Diário" : p}</button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={movimentacao[periodo]}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="p" /><YAxis /><Tooltip /><Legend />
              <Bar dataKey="entrada" name="Entrada" fill="#0f766e" radius={[4, 4, 0, 0]} /><Bar dataKey="saida" name="Saída" fill="#d97706" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <h2 className="mb-3 text-sm font-semibold">Receita por canal (R$ mil)</h2>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={receitaCanal}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="m" /><YAxis /><Tooltip /><Legend />
              <Bar dataKey="atacado" name="Atacado" stackId="a" fill="#0f766e" /><Bar dataKey="varejo" name="Varejo" stackId="a" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 lg:col-span-2">
          <h2 className="mb-3 text-sm font-semibold">Fluxo de caixa projetado (R$ mil)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={fluxoCaixa}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="s" /><YAxis /><Tooltip /><Legend />
              <Line type="monotone" dataKey="receber" name="A receber" stroke="#0f766e" strokeWidth={2} /><Line type="monotone" dataKey="pagar" name="A pagar" stroke="#dc2626" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mt-6 grid gap-4 xl:grid-cols-2">
        <Tabela titulo="Próximos do vencimento (FEFO)" cab={["Produto", "Validade", "Qtd", "Status"]}>
          {lotes.map((l) => (
            <tr key={l.id} className="border-t border-slate-100">
              <td className="py-2 pr-2">{l.produto}<span className="block text-xs text-slate-400">{l.lote}</span></td>
              <td>{dataBR(l.validade)}</td><td>{l.qtd}</td><td><Badge s={l.status} /></td>
              <td><Acoes onView={() => setModal({ kind: "lote", mode: "ver", id: l.id })} onEdit={() => setModal({ kind: "lote", mode: "editar", id: l.id })} onDelete={() => setModal({ kind: "lote", mode: "excluir", id: l.id })} /></td>
            </tr>
          ))}
        </Tabela>
        <Tabela titulo="Contas a pagar e a receber" cab={["Descrição", "Valor", "Vencimento", "Status"]}>
          {contas.map((c) => (
            <tr key={c.id} className="border-t border-slate-100">
              <td className="py-2 pr-2">{c.descricao}<span className="block text-xs text-slate-400">{c.tipo}</span></td>
              <td>{brl(c.valor)}</td><td>{dataBR(c.vencimento)}</td><td><Badge s={c.status} /></td>
              <td><Acoes onView={() => setModal({ kind: "conta", mode: "ver", id: c.id })} onEdit={() => setModal({ kind: "conta", mode: "editar", id: c.id })} onDelete={() => setModal({ kind: "conta", mode: "excluir", id: c.id })} /></td>
            </tr>
          ))}
        </Tabela>
      </section>

      {modal && alvo && (
        <Modal titulo={modal.mode === "ver" ? "Detalhes" : modal.mode === "editar" ? "Editar registro" : "Excluir registro"} onClose={fechar}>
          {modal.mode === "excluir" ? (
            <>
              <p className="text-sm">Excluir <strong>{alvo.produto ?? alvo.descricao}</strong>? Essa ação não pode ser desfeita.</p>
              <div className="mt-5 flex justify-end gap-2">
                <button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
                <button onClick={confirmarExclusao} className="rounded-lg bg-red-600 px-4 py-2 text-sm text-white">Excluir</button>
              </div>
            </>
          ) : (
            <form onSubmit={salvar} className="space-y-3" key={alvo.id + modal.mode}>
              {campos.map(([n, l, t]) => (
                <label key={n} className="block text-sm">{l}
                  <input name={n} type={t} step="any" defaultValue={alvo[n]} disabled={modal.mode === "ver"} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 disabled:bg-slate-50" />
                  {erros[n] && <span className="text-xs text-red-600">{erros[n]}</span>}
                </label>
              ))}
              {modal.kind === "conta" && (
                <label className="block text-sm">Status
                  <select name="status" defaultValue={alvo.status} disabled={modal.mode === "ver"} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 disabled:bg-slate-50">
                    {["Pendente", "Pago", "Atrasado"].map((s) => <option key={s}>{s}</option>)}
                  </select>
                </label>
              )}
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">{modal.mode === "ver" ? "Fechar" : "Cancelar"}</button>
                {modal.mode === "editar" && <button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white">Salvar alterações</button>}
              </div>
            </form>
          )}
        </Modal>
      )}
    </main>
  );
}

function Tabela({ titulo, cab, children }: { titulo: string; cab: string[]; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <h2 className="mb-3 text-sm font-semibold">{titulo}</h2>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[480px] text-left text-sm">
          <thead className="text-xs text-slate-500"><tr>{cab.map((c) => <th key={c} className="pb-2 font-medium">{c}</th>)}<th className="pb-2 text-right font-medium">Ações</th></tr></thead>
          <tbody>{children}</tbody>
        </table>
      </div>
    </div>
  );
}

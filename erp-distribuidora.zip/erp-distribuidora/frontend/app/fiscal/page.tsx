"use client";
import { useMemo, useState } from "react";
import { z } from "zod";
import { Eye, Pencil, Trash2, FileText, Ban, FilePen, Eraser, X, Loader2 } from "lucide-react";
import { brl, cancelarNotaMock, emitirNotaMock } from "@/lib/mock";

type Status = "Aguardando emissão" | "Autorizada" | "Cancelada" | "Inutilizada" | "Rejeitada";
type Evento = { tipo: string; texto: string; em: string };
type Nota = { id: string; modelo: 55 | 65; serie: number; numero: number; destinatario: string; natureza: string; valor: number; status: Status; chave?: string; motivo?: string; eventos: Evento[] };

const cor: Record<Status, string> = {
  "Aguardando emissão": "bg-amber-100 text-amber-800", Autorizada: "bg-emerald-100 text-emerald-800",
  Cancelada: "bg-red-100 text-red-800", Inutilizada: "bg-slate-200 text-slate-700", Rejeitada: "bg-orange-100 text-orange-800",
};
const just = z.string().trim().min(15, "A justificativa precisa ter ao menos 15 caracteres").max(255);
const editSchema = z.object({ destinatario: z.string().trim().min(3, "Informe o destinatário"), natureza: z.string().trim().min(3, "Informe a natureza da operação") });
const inutSchema = z.object({
  serie: z.coerce.number().int().min(1, "Série inválida"), ini: z.coerce.number().int().min(1, "Número inválido"),
  fim: z.coerce.number().int().min(1, "Número inválido"), justificativa: just,
}).refine((d) => d.fim >= d.ini, { path: ["fim"], message: "O número final deve ser maior ou igual ao inicial" });

const agora = () => new Date().toLocaleString("pt-BR");
const dig = (n: number) => Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join("");

export default function FiscalPage() {
  const [notas, setNotas] = useState<Nota[]>([
    { id: "1", modelo: 55, serie: 1, numero: 2051, destinatario: "Mercadinho Boa Vista", natureza: "Venda de mercadoria", valor: 9320.5, status: "Aguardando emissão", eventos: [] },
    { id: "2", modelo: 55, serie: 1, numero: 2050, destinatario: "Restaurante Sabor do Mar", natureza: "Venda de mercadoria", valor: 8160, status: "Autorizada", chave: "26261012345678000199550010000020501000020509", eventos: [{ tipo: "Autorização", texto: "Protocolo 126260000012345", em: "02/10/2026 09:12" }] },
    { id: "3", modelo: 65, serie: 1, numero: 8812, destinatario: "Consumidor final", natureza: "Venda ao consumidor", valor: 142.7, status: "Rejeitada", motivo: "Rejeição 539: NCM inválido para o item 2", eventos: [] },
  ]);
  const [fMod, setFMod] = useState("todos"); const [fSt, setFSt] = useState("todos");
  const [modal, setModal] = useState<null | { mode: "ver" | "editar" | "excluir" | "cancelar" | "cce" | "inutilizar"; id?: string }>(null);
  const [texto, setTexto] = useState(""); const [erros, setErros] = useState<Record<string, string>>({});
  const [ocupado, setOcupado] = useState<string | null>(null); const [msg, setMsg] = useState("");

  const lista = useMemo(() => notas.filter((n) => (fMod === "todos" || String(n.modelo) === fMod) && (fSt === "todos" || n.status === fSt)), [notas, fMod, fSt]);
  const atual = notas.find((n) => n.id === modal?.id);
  const upd = (id: string, patch: Partial<Nota>, ev?: Evento) => setNotas((l) => l.map((n) => (n.id === id ? { ...n, ...patch, eventos: ev ? [ev, ...n.eventos] : n.eventos } : n)));
  const abrir = (mode: NonNullable<typeof modal>["mode"], n?: Nota) => { setTexto(""); setErros({}); setModal({ mode, id: n?.id }); };
  const fechar = () => { setModal(null); setErros({}); };

  async function emitir(n: Nota) {
    setOcupado(n.id); setMsg("");
    const r = await emitirNotaMock(n.modelo); // TODO: POST /api/fiscal/emitir (backend assina com A1/A3 e transmite)
    upd(n.id, { status: "Autorizada", chave: r.chave, motivo: undefined }, { tipo: "Autorização", texto: `Protocolo ${r.protocolo}`, em: agora() });
    setMsg(`Nota ${n.numero} autorizada (ambiente simulado).`); setOcupado(null);
  }
  async function cancelar() {
    const r = just.safeParse(texto); if (!r.success || !atual) return setErros({ texto: r.error?.issues[0].message ?? "" });
    setOcupado(atual.id); await cancelarNotaMock(); // TODO: evento 110111 (prazo legal: confira a regra da SEFAZ da sua UF)
    upd(atual.id, { status: "Cancelada" }, { tipo: "Cancelamento", texto: r.data, em: agora() }); setOcupado(null); fechar(); setMsg(`Nota ${atual.numero} cancelada.`);
  }
  function cce() {
    const r = z.string().trim().min(15, "A correção precisa ter ao menos 15 caracteres").max(1000, "Máximo de 1000 caracteres").safeParse(texto);
    if (!r.success || !atual) return setErros({ texto: r.error?.issues[0].message ?? "" });
    upd(atual.id, {}, { tipo: `Carta de Correção nº ${atual.eventos.filter((e) => e.tipo.startsWith("Carta")).length + 1}`, texto: r.data, em: agora() }); // TODO: evento 110110
    fechar(); setMsg("Carta de Correção registrada.");
  }
  function inutilizar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const r = inutSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!r.success) return setErros(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message])));
    const { serie, ini, fim } = r.data; // TODO: POST /api/fiscal/inutilizar (só números não utilizados)
    const conflito = notas.find((n) => n.serie === serie && n.numero >= ini && n.numero <= fim && n.status !== "Inutilizada");
    if (conflito) return setErros({ ini: `O número ${conflito.numero} já foi usado e não pode ser inutilizado` });
    const novas: Nota[] = Array.from({ length: Math.min(fim - ini + 1, 50) }, (_, i) => ({ id: crypto.randomUUID(), modelo: 55, serie, numero: ini + i, destinatario: "—", natureza: "Numeração inutilizada", valor: 0, status: "Inutilizada", eventos: [{ tipo: "Inutilização", texto: r.data.justificativa, em: agora() }] }));
    setNotas((l) => [...novas, ...l]); fechar(); setMsg(`${novas.length} número(s) inutilizado(s) na série ${serie}.`);
  }
  function salvarEdicao(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const r = editSchema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!r.success) return setErros(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message])));
    if (atual) upd(atual.id, { ...r.data, status: atual.status === "Rejeitada" ? "Aguardando emissão" : atual.status }); fechar(); // TODO: PATCH /api/invoices/:id
  }

  const editavel = atual && (atual.status === "Aguardando emissão" || atual.status === "Rejeitada");
  const inp = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50";
  const Btns = ({ onOk, ok, danger }: { onOk: () => void; ok: string; danger?: boolean }) => (
    <div className="mt-4 flex justify-end gap-2"><button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Voltar</button>
      <button onClick={onOk} disabled={!!ocupado} className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm text-white disabled:opacity-60 ${danger ? "bg-red-600" : "bg-teal-700"}`}>{ocupado && <Loader2 size={14} className="animate-spin" />}{ok}</button></div>
  );

  return (
    <main className="p-4 md:p-8">
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-semibold text-slate-900">Notas fiscais</h1><p className="text-sm text-slate-500">NF-e (modelo 55) e NFC-e (modelo 65) · ambiente simulado</p></div>
        <button onClick={() => abrir("inutilizar")} className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"><Eraser size={16} /> Inutilizar numeração</button>
      </header>
      {msg && <p className="mb-4 rounded-lg bg-teal-50 px-4 py-2 text-sm text-teal-900" role="status">{msg}</p>}
      <div className="mb-4 flex gap-2 text-sm">
        <select value={fMod} onChange={(e) => setFMod(e.target.value)} className="rounded-lg border border-slate-300 bg-white px-3 py-2" aria-label="Modelo"><option value="todos">Todos os modelos</option><option value="55">NF-e (55)</option><option value="65">NFC-e (65)</option></select>
        <select value={fSt} onChange={(e) => setFSt(e.target.value)} className="rounded-lg border border-slate-300 bg-white px-3 py-2" aria-label="Status"><option value="todos">Todos os status</option>{Object.keys(cor).map((s) => <option key={s}>{s}</option>)}</select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table className="w-full min-w-[880px] text-left text-sm">
        <thead className="bg-slate-50 text-xs text-slate-500"><tr>{["Nota", "Destinatário", "Valor", "Status", "Ações"].map((c) => <th key={c} className={`px-4 py-3 font-medium ${c === "Ações" ? "text-right" : ""}`}>{c}</th>)}</tr></thead>
        <tbody>
          {lista.map((n) => (
            <tr key={n.id} className="border-t border-slate-100">
              <td className="px-4 py-3 font-medium">{n.modelo === 55 ? "NF-e" : "NFC-e"} {n.numero}<span className="block text-xs font-normal text-slate-400">Série {n.serie}</span></td>
              <td className="px-4">{n.destinatario}<span className="block text-xs text-slate-400">{n.natureza}</span></td><td className="px-4">{brl(n.valor)}</td>
              <td className="px-4"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${cor[n.status]}`}>{n.status}</span>{n.motivo && <span className="block text-xs text-orange-700">{n.motivo}</span>}</td>
              <td className="px-4"><div className="flex items-center justify-end gap-1">
                {(n.status === "Aguardando emissão" || n.status === "Rejeitada") && <button disabled={!!ocupado} onClick={() => emitir(n)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-teal-800 hover:bg-teal-50 disabled:opacity-50">{ocupado === n.id ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />} Emitir</button>}
                {n.status === "Autorizada" && <><button onClick={() => abrir("cce", n)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-sky-800 hover:bg-sky-50"><FilePen size={14} /> CC-e</button>
                  <button onClick={() => abrir("cancelar", n)} className="flex items-center gap-1 rounded px-2 py-1 text-xs text-red-700 hover:bg-red-50"><Ban size={14} /> Cancelar</button></>}
                {([[Eye, "Visualizar", "ver"], [Pencil, "Editar", "editar"], [Trash2, "Excluir", "excluir"]] as const).map(([I, l, m]) => <button key={l} title={l} aria-label={l} onClick={() => abrir(m, n)} className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"><I size={16} /></button>)}
              </div></td>
            </tr>
          ))}
          {!lista.length && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-500">Nenhuma nota com esses filtros.</td></tr>}
        </tbody></table></div>

      {modal && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-slate-900/40 p-4" onClick={fechar} role="dialog" aria-modal="true">
          <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between"><h2 className="text-base font-semibold">{{ ver: `Nota ${atual?.numero}`, editar: `Editar nota ${atual?.numero}`, excluir: "Excluir nota", cancelar: `Cancelar nota ${atual?.numero}`, cce: `Carta de Correção · nota ${atual?.numero}`, inutilizar: "Inutilizar numeração" }[modal.mode]}</h2><button onClick={fechar} aria-label="Fechar" className="rounded p-1 hover:bg-slate-100"><X size={18} /></button></div>

            {modal.mode === "ver" && atual && <>
              <dl className="space-y-1 text-sm"><div>Destinatário: {atual.destinatario}</div><div>Valor: {brl(atual.valor)}</div>{atual.chave && <div className="break-all text-xs text-slate-500">Chave: {atual.chave}</div>}</dl>
              <h3 className="mb-1 mt-3 text-xs font-semibold text-slate-500">EVENTOS</h3>
              <ul className="space-y-1 text-sm">{atual.eventos.map((e, i) => <li key={i} className="rounded bg-slate-50 px-3 py-2"><strong>{e.tipo}</strong> · <span className="text-xs text-slate-500">{e.em}</span><br />{e.texto}</li>)}{!atual.eventos.length && <li className="text-slate-400">Nenhum evento registrado.</li>}</ul>
              <div className="mt-4 flex justify-end"><button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Fechar</button></div></>}

            {modal.mode === "editar" && atual && (
              <form onSubmit={salvarEdicao} className="space-y-3 text-sm" key={atual.id}>
                {!editavel && <p className="rounded-lg bg-slate-100 px-3 py-2 text-xs">Nota {atual.status.toLowerCase()} não pode ser editada. Para corrigir dados permitidos, use a Carta de Correção.</p>}
                <label className="block">Destinatário<input name="destinatario" defaultValue={atual.destinatario} disabled={!editavel} className={inp} />{erros.destinatario && <span className="text-xs text-red-600">{erros.destinatario}</span>}</label>
                <label className="block">Natureza da operação<input name="natureza" defaultValue={atual.natureza} disabled={!editavel} className={inp} />{erros.natureza && <span className="text-xs text-red-600">{erros.natureza}</span>}</label>
                <div className="flex justify-end gap-2 pt-1"><button type="button" onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>{editavel && <button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-white">Salvar</button>}</div>
              </form>)}

            {modal.mode === "excluir" && atual && (atual.status === "Autorizada"
              ? <><p className="text-sm">A nota <strong>{atual.numero}</strong> está autorizada na SEFAZ e não pode ser excluída. Cancele a nota dentro do prazo legal.</p><div className="mt-4 flex justify-end"><button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Entendi</button></div></>
              : <><p className="text-sm">Excluir o registro da nota <strong>{atual.numero}</strong>? Se o número já foi reservado, inutilize-o depois.</p><Btns danger ok="Excluir" onOk={() => { setNotas((l) => l.filter((n) => n.id !== atual.id)); fechar(); }} /></>)}

            {(modal.mode === "cancelar" || modal.mode === "cce") && (<>
              <label className="block text-sm">{modal.mode === "cancelar" ? "Justificativa do cancelamento" : "Texto da correção"}
                <textarea value={texto} onChange={(e) => setTexto(e.target.value)} rows={4} className={inp} />{erros.texto && <span className="text-xs text-red-600">{erros.texto}</span>}</label>
              {modal.mode === "cce" && <p className="mt-1 text-xs text-slate-500">A CC-e não pode alterar valores, impostos, base de cálculo, destinatário nem data de emissão.</p>}
              <Btns danger={modal.mode === "cancelar"} ok={modal.mode === "cancelar" ? "Cancelar nota" : "Registrar correção"} onOk={modal.mode === "cancelar" ? cancelar : cce} /></>)}

            {modal.mode === "inutilizar" && (
              <form onSubmit={inutilizar} className="grid grid-cols-3 gap-3 text-sm">
                {([["serie", "Série"], ["ini", "Nº inicial"], ["fim", "Nº final"]] as const).map(([k, l]) => <label key={k}>{l}<input name={k} type="number" min="1" className={inp} />{erros[k] && <span className="text-xs text-red-600">{erros[k]}</span>}</label>)}
                <label className="col-span-3">Justificativa<textarea name="justificativa" rows={3} className={inp} />{erros.justificativa && <span className="text-xs text-red-600">{erros.justificativa}</span>}</label>
                <div className="col-span-3 flex justify-end gap-2"><button type="button" onClick={fechar} className="rounded-lg border px-4 py-2">Cancelar</button><button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-white">Inutilizar</button></div>
              </form>)}
          </div>
        </div>
      )}
    </main>
  );
}

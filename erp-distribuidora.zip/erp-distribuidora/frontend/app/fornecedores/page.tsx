"use client";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { Eye, Pencil, Trash2, Plus, Search, Download, X, Loader2, Star } from "lucide-react";
import { api, ApiError, erroMsg } from "@/lib/api";

/* ───────── CNPJ ───────── */
const soDigitos = (v: string) => v.replace(/\D/g, "");
const mascaraCNPJ = (v: string) =>
  soDigitos(v).slice(0, 14).replace(/^(\d{2})(\d)/, "$1.$2").replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3").replace(/\.(\d{3})(\d)/, ".$1/$2").replace(/(\d{4})(\d)/, "$1-$2");

function cnpjValido(v: string) {
  const c = soDigitos(v);
  if (c.length !== 14 || /^(\d)\1+$/.test(c)) return false;
  const dv = (base: string) => {
    let soma = 0, peso = base.length - 7;
    for (const n of base) { soma += +n * peso--; if (peso < 2) peso = 9; }
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  return dv(c.slice(0, 12)) === +c[12] && dv(c.slice(0, 13)) === +c[13];
}

/* ───────── Tipos, schema e dados mock ───────── */
const schema = z.object({
  razao: z.string().min(3, "Informe a razão social"),
  fantasia: z.string().optional(),
  cnpj: z.string().refine(cnpjValido, "CNPJ inválido"),
  ie: z.string().optional(),
  endereco: z.string().min(5, "Informe o endereço"),
  telefone: z.string().min(8, "Informe um telefone"),
  email: z.string().email("E-mail inválido"),
  condicoes: z.string().optional(),
  ativo: z.boolean(),
});
type Dados = z.infer<typeof schema>;
type Fornecedor = Dados & { id: string; produtos: number; leadTime: number; nota: number; compras: number };

const vazio: Dados = { razao: "", fantasia: "", cnpj: "", ie: "", endereco: "", telefone: "", email: "", condicoes: "", ativo: true };

// Conversão entre o formato da API (Prisma) e o do formulário
const deApi = (s: any): Fornecedor => ({
  id: s.id, razao: s.legalName, fantasia: s.tradeName ?? "", cnpj: mascaraCNPJ(s.cnpj), ie: s.stateRegistration ?? "",
  endereco: s.address?.text ?? "", telefone: s.phones?.[0] ?? "", email: s.orderEmail ?? "", condicoes: s.paymentTerms ?? "", ativo: s.active,
  produtos: s._count?.products ?? 0, leadTime: Number(s.avgLeadTimeDays ?? 0), nota: Number(s.rating ?? 0), compras: s._count?.purchases ?? 0,
});
const paraApi = (d: Dados) => ({
  legalName: d.razao, tradeName: d.fantasia ?? "", cnpj: soDigitos(d.cnpj), stateRegistration: d.ie ?? "", address: { text: d.endereco },
  phones: [d.telefone], orderEmail: d.email, paymentTerms: d.condicoes ?? "", active: d.ativo,
});

/* ───────── UI ───────── */
const Campo = ({ l, erro, children }: { l: string; erro?: string; children: React.ReactNode }) => (
  <label className="block text-sm text-slate-700">{l}{children}{erro && <span className="block text-xs text-red-600">{erro}</span>}</label>
);
const inp = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50";

export default function FornecedoresPage() {
  const [lista, setLista] = useState<Fornecedor[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erroApi, setErroApi] = useState("");
  const [salvando, setSalvando] = useState(false);
  const carregar = async () => {
    try { setLista((await api<any[]>("/suppliers?take=200")).map(deApi)); setErroApi(""); }
    catch (e) { setErroApi(erroMsg(e)); }
    finally { setCarregando(false); }
  };
  useEffect(() => { carregar(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const [busca, setBusca] = useState("");
  const [filtro, setFiltro] = useState<"todos" | "ativos" | "inativos">("todos");
  const [modal, setModal] = useState<null | { mode: "novo" | "ver" | "editar" | "excluir"; id?: string }>(null);
  const [form, setForm] = useState<Dados>(vazio);
  const [erros, setErros] = useState<Record<string, string>>({});
  const [buscandoCnpj, setBuscandoCnpj] = useState(false);
  const [aviso, setAviso] = useState("");

  const filtrada = useMemo(() => {
    const q = busca.toLowerCase();
    return lista.filter((f) =>
      (filtro === "todos" || (filtro === "ativos") === f.ativo) &&
      (!q || [f.razao, f.fantasia, f.cnpj].some((x) => x?.toLowerCase().includes(q))));
  }, [lista, busca, filtro]);

  const atual = modal?.id ? lista.find((f) => f.id === modal.id) : undefined;
  const ro = modal?.mode === "ver";
  const set = (k: keyof Dados, v: string | boolean) => setForm((f) => ({ ...f, [k]: v }));

  function abrir(mode: "novo" | "ver" | "editar" | "excluir", f?: Fornecedor) {
    setForm(f ? { razao: f.razao, fantasia: f.fantasia, cnpj: f.cnpj, ie: f.ie, endereco: f.endereco, telefone: f.telefone, email: f.email, condicoes: f.condicoes, ativo: f.ativo } : vazio);
    setErros({}); setAviso(""); setModal({ mode, id: f?.id });
  }
  const fechar = () => setModal(null);

  async function buscarCnpj() {
    setAviso("");
    if (!cnpjValido(form.cnpj)) return setErros({ cnpj: "CNPJ inválido" });
    setBuscandoCnpj(true);
    try {
      const r = await fetch(`/api/cnpj/${soDigitos(form.cnpj)}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setForm((f) => ({ ...f, razao: d.razao || f.razao, fantasia: d.fantasia || f.fantasia, ie: d.ie || f.ie, endereco: d.endereco || f.endereco, telefone: d.telefone || f.telefone, email: d.email || f.email }));
      setErros({}); setAviso("Dados preenchidos pela consulta do CNPJ. Confira antes de salvar.");
    } catch (e: any) {
      setAviso(e.message ?? "Não foi possível consultar o CNPJ. Preencha manualmente.");
    } finally { setBuscandoCnpj(false); }
  }

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    const r = schema.safeParse(form);
    if (!r.success) return setErros(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message])));
    setSalvando(true);
    try {
      if (modal?.mode === "editar") await api(`/suppliers/${modal.id}`, { method: "PATCH", body: paraApi(r.data) });
      else await api("/suppliers", { method: "POST", body: paraApi(r.data) });
      await carregar(); fechar();
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) setErros({ cnpj: "Já existe fornecedor com este CNPJ" });
      else setAviso(erroMsg(err));
    } finally { setSalvando(false); }
  }

  async function excluir() {
    try { await api(`/suppliers/${modal?.id}`, { method: "DELETE" }); await carregar(); }
    catch (err) { setErroApi(err instanceof ApiError && err.status === 409 ? "Este fornecedor possui compras ou produtos vinculados. Inative-o em vez de excluir." : erroMsg(err)); }
    fechar();
  }

  function exportarCSV() {
    const cab = ["Razão social", "Fantasia", "CNPJ", "E-mail", "Telefone", "Status"];
    const linhas = filtrada.map((f) => [f.razao, f.fantasia, f.cnpj, f.email, f.telefone, f.ativo ? "Ativo" : "Inativo"]);
    const blob = new Blob([[cab, ...linhas].map((l) => l.join(";")).join("\n")], { type: "text/csv;charset=utf-8" });
    const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: "fornecedores.csv" });
    a.click(); URL.revokeObjectURL(a.href);
  }

  return (
    <main className="p-4 md:p-8">
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Fornecedores</h1>
          <p className="text-sm text-slate-500">{filtrada.length} de {lista.length} cadastrados</p>
        </div>
        <div className="flex gap-2">
          <button onClick={exportarCSV} className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"><Download size={16} /> Exportar CSV</button>
          <button onClick={() => abrir("novo")} className="flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800"><Plus size={16} /> Novo fornecedor</button>
        </div>
      </header>

      {erroApi && <p className="mb-4 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-800" role="alert">{erroApi}</p>}
      <div className="mb-4 flex flex-wrap gap-2">
        <div className="relative min-w-[240px] flex-1">
          <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
          <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar por razão social, fantasia ou CNPJ" className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm" />
        </div>
        <select value={filtro} onChange={(e) => setFiltro(e.target.value as any)} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="todos">Todos</option><option value="ativos">Ativos</option><option value="inativos">Inativos</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="bg-slate-50 text-xs text-slate-500">
            <tr>{["Fornecedor", "CNPJ", "Produtos", "Lead time", "Avaliação", "Status", "Ações"].map((c) => <th key={c} className={`px-4 py-3 font-medium ${c === "Ações" ? "text-right" : ""}`}>{c}</th>)}</tr>
          </thead>
          <tbody>
            {filtrada.map((f) => (
              <tr key={f.id} className="border-t border-slate-100">
                <td className="px-4 py-3">{f.razao}<span className="block text-xs text-slate-400">{f.fantasia || f.email}</span></td>
                <td className="px-4">{f.cnpj}</td>
                <td className="px-4">{f.produtos}</td>
                <td className="px-4">{f.leadTime ? `${f.leadTime} dias` : "—"}</td>
                <td className="px-4"><span className="inline-flex items-center gap-1"><Star size={14} className="text-amber-500" />{f.nota ? f.nota.toFixed(1) : "—"}</span></td>
                <td className="px-4"><span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${f.ativo ? "bg-emerald-100 text-emerald-800" : "bg-slate-200 text-slate-700"}`}>{f.ativo ? "Ativo" : "Inativo"}</span></td>
                <td className="px-4">
                  <div className="flex justify-end gap-1">
                    {([[Eye, "Visualizar", "ver"], [Pencil, "Editar", "editar"], [Trash2, "Excluir", "excluir"]] as const).map(([I, l, m]) => (
                      <button key={l} title={l} aria-label={l} onClick={() => abrir(m, f)} className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"><I size={16} /></button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
            {!filtrada.length && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-500">{carregando ? "Carregando…" : "Nenhum fornecedor encontrado. Ajuste a busca ou cadastre um novo."}</td></tr>}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-slate-900/40 p-4" onClick={fechar} role="dialog" aria-modal="true">
          <div className="w-full max-w-xl rounded-xl bg-white p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-semibold">{{ novo: "Novo fornecedor", ver: "Detalhes do fornecedor", editar: "Editar fornecedor", excluir: "Excluir fornecedor" }[modal.mode]}</h2>
              <button onClick={fechar} aria-label="Fechar" className="rounded p-1 hover:bg-slate-100"><X size={18} /></button>
            </div>

            {modal.mode === "excluir" ? (
              <>
                <p className="text-sm">Excluir <strong>{atual?.razao}</strong>? Os vínculos com produtos serão removidos.</p>
                <div className="mt-5 flex justify-end gap-2">
                  <button onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
                  <button onClick={excluir} className="rounded-lg bg-red-600 px-4 py-2 text-sm text-white">Excluir</button>
                </div>
              </>
            ) : (
              <form onSubmit={salvar} className="grid gap-3 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Campo l="CNPJ" erro={erros.cnpj}>
                    <div className="flex gap-2">
                      <input disabled={ro} value={form.cnpj} onChange={(e) => set("cnpj", mascaraCNPJ(e.target.value))} placeholder="00.000.000/0000-00" className={inp} />
                      {!ro && (
                        <button type="button" onClick={buscarCnpj} disabled={buscandoCnpj} className="mt-1 flex shrink-0 items-center gap-2 rounded-lg border border-teal-700 px-3 text-sm text-teal-800 disabled:opacity-60">
                          {buscandoCnpj ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />} Buscar dados
                        </button>
                      )}
                    </div>
                  </Campo>
                  {aviso && <p className="mt-1 text-xs text-slate-600">{aviso}</p>}
                </div>
                <div className="sm:col-span-2"><Campo l="Razão social" erro={erros.razao}><input disabled={ro} value={form.razao} onChange={(e) => set("razao", e.target.value)} className={inp} /></Campo></div>
                <Campo l="Nome fantasia"><input disabled={ro} value={form.fantasia} onChange={(e) => set("fantasia", e.target.value)} className={inp} /></Campo>
                <Campo l="Inscrição estadual"><input disabled={ro} value={form.ie} onChange={(e) => set("ie", e.target.value)} className={inp} /></Campo>
                <div className="sm:col-span-2"><Campo l="Endereço" erro={erros.endereco}><input disabled={ro} value={form.endereco} onChange={(e) => set("endereco", e.target.value)} className={inp} /></Campo></div>
                <Campo l="Telefone" erro={erros.telefone}><input disabled={ro} value={form.telefone} onChange={(e) => set("telefone", e.target.value)} className={inp} /></Campo>
                <Campo l="E-mail de pedidos" erro={erros.email}><input disabled={ro} type="email" value={form.email} onChange={(e) => set("email", e.target.value)} className={inp} /></Campo>
                <div className="sm:col-span-2"><Campo l="Condições comerciais padrão"><input disabled={ro} value={form.condicoes} onChange={(e) => set("condicoes", e.target.value)} className={inp} /></Campo></div>
                <label className="flex items-center gap-2 text-sm sm:col-span-2"><input disabled={ro} type="checkbox" checked={form.ativo} onChange={(e) => set("ativo", e.target.checked)} /> Fornecedor ativo</label>

                {ro && atual && (
                  <dl className="grid grid-cols-3 gap-2 rounded-lg bg-slate-50 p-3 text-center text-xs sm:col-span-2">
                    <div><dt className="text-slate-500">Compras</dt><dd className="text-base font-semibold">{atual.compras}</dd></div>
                    <div><dt className="text-slate-500">Lead time médio</dt><dd className="text-base font-semibold">{atual.leadTime || "—"} dias</dd></div>
                    <div><dt className="text-slate-500">Produtos vinculados</dt><dd className="text-base font-semibold">{atual.produtos}</dd></div>
                  </dl>
                )}

                <div className="flex justify-end gap-2 pt-2 sm:col-span-2">
                  <button type="button" onClick={fechar} className="rounded-lg border px-4 py-2 text-sm">{ro ? "Fechar" : "Cancelar"}</button>
                  {!ro && <button type="submit" disabled={salvando} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white disabled:opacity-60">{modal.mode === "novo" ? "Cadastrar fornecedor" : "Salvar alterações"}</button>}
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </main>
  );
}

const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3333/api";
const KEY = "erp_token";

// sessionStorage: some ao fechar a aba. Para produção, prefira cookie httpOnly emitido por um BFF (mitiga roubo de token via XSS).
export const token = {
  get: () => (typeof window === "undefined" ? null : sessionStorage.getItem(KEY)),
  set: (t: string) => sessionStorage.setItem(KEY, t),
  clear: () => sessionStorage.removeItem(KEY),
};

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export async function api<T = any>(path: string, opt: { method?: string; body?: unknown } = {}): Promise<T> {
  const t = token.get();
  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      method: opt.method ?? "GET",
      headers: { "Content-Type": "application/json", ...(t ? { Authorization: `Bearer ${t}` } : {}) },
      body: opt.body === undefined ? undefined : JSON.stringify(opt.body),
    });
  } catch {
    throw new ApiError(0, "Não foi possível conectar à API. Verifique se o servidor está rodando.");
  }
  if (res.status === 401 && !path.startsWith("/auth/login")) {
    token.clear();
    if (typeof window !== "undefined") window.location.href = "/login";
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, mensagem(data) || `Erro ${res.status}`);
  return data as T;
}

// A API devolve {message: string} ou o resultado do zod.flatten() ({formErrors, fieldErrors}).
function mensagem(d: any): string {
  const m = d?.message ?? d;
  if (typeof m === "string") return m;
  if (m?.fieldErrors && Object.keys(m.fieldErrors).length)
    return "Dados inválidos: " + Object.entries(m.fieldErrors).map(([k, v]) => `${k}: ${(v as string[])[0]}`).join("; ");
  return m?.formErrors?.[0] ?? "";
}

export const erroMsg = (e: unknown) => (e instanceof Error ? e.message : "Erro inesperado");

"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { api, token } from "./api";

export type Role = "ADMIN" | "GERENTE" | "VENDEDOR" | "CAIXA" | "ESTOQUISTA" | "FINANCEIRO";
export type User = { id: string; name: string; email: string; role: Role };
type Ctx = { user: User | null | undefined; login: (email: string, password: string) => Promise<void>; logout: () => void };

const AuthCtx = createContext<Ctx>(null as unknown as Ctx);
export const useAuth = () => useContext(AuthCtx);

/** user: undefined = verificando sessão · null = deslogado · objeto = logado */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null | undefined>(undefined);

  useEffect(() => {
    if (!token.get()) return setUser(null);
    api<User>("/auth/me").then(setUser).catch(() => { token.clear(); setUser(null); });
  }, []);

  async function login(email: string, password: string) {
    const r = await api<{ token: string; user: User }>("/auth/login", { method: "POST", body: { email, password } });
    token.set(r.token);
    setUser(r.user);
  }
  function logout() { token.clear(); setUser(null); }

  return <AuthCtx.Provider value={{ user, login, logout }}>{children}</AuthCtx.Provider>;
}

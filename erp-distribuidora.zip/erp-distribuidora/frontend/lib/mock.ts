export type Prod = { sku: string; barcode: string; nome: string; porKg: boolean; precoVarejo: number; tiers: { min: number; preco: number }[] };

export const catalogo: Prod[] = [
  { sku: "LEI-001", barcode: "7891000100103", nome: "Leite UHT Integral 1L (cx 12)", porKg: false, precoVarejo: 74.9, tiers: [{ min: 1, preco: 66 }, { min: 10, preco: 63 }, { min: 50, preco: 60.5 }] },
  { sku: "SUC-020", barcode: "7891000200200", nome: "Suco de Uva Integral 1L (cx 6)", porKg: false, precoVarejo: 59.9, tiers: [{ min: 1, preco: 53 }, { min: 20, preco: 50 }, { min: 80, preco: 47.5 }] },
  { sku: "ARR-030", barcode: "7891000300307", nome: "Arroz Branco Tipo 1 (fardo 30kg)", porKg: false, precoVarejo: 189, tiers: [{ min: 1, preco: 168 }, { min: 5, preco: 160 }, { min: 20, preco: 152 }] },
  { sku: "QJM-040", barcode: "2000000000401", nome: "Queijo Mussarela fatiado (kg)", porKg: true, precoVarejo: 49.9, tiers: [{ min: 1, preco: 42 }, { min: 10, preco: 39.5 }] },
];

/** Preço progressivo do atacado: usa a maior faixa cujo mínimo foi atingido. */
export const precoAtacado = (p: Prod, qtd: number) =>
  [...p.tiers].reverse().find((t) => qtd >= t.min)?.preco ?? p.tiers[0].preco;

export const brl = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

/** MOCK da SEFAZ. Substitua por POST /api/fiscal/emitir (backend assina com certificado A1/A3). */
export async function emitirNotaMock(modelo: 55 | 65) {
  await new Promise((r) => setTimeout(r, 900));
  const dig = (n: number) => Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join("");
  return { chave: `26${dig(6)}${dig(14)}${modelo}${dig(23)}`.slice(0, 44), protocolo: dig(15), autorizadaEm: new Date().toISOString() };
}
export async function cancelarNotaMock() {
  await new Promise((r) => setTimeout(r, 600));
  return { protocoloCancelamento: String(Math.floor(Math.random() * 1e15)) };
}

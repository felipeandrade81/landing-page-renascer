# DistribuiERP: ERP para distribuidora de alimentos e bebidas (Atacado + Varejo)

Next.js 15 + Tailwind (frontend) · NestJS + Prisma + PostgreSQL (backend).

## Como rodar

```bash
# 1) Banco
docker compose up -d

# 2) API (porta 3333)
cd backend
cp .env.example .env       # preencha JWT_SECRET: openssl rand -base64 48
npm install
npx prisma migrate dev --name init
npx prisma db seed          # cria 1 usuário por perfil e imprime a senha (uma única vez)
npm run start:dev

# 3) Frontend (porta 3000)
cd ../frontend
npm install
npm run dev
```

Entre em http://localhost:3000 com `admin@distribuierp.local` (ou `gerente@`, `vendedor@`, `caixa@`, `estoquista@`, `financeiro@`) e a senha impressa pelo seed. O menu mostra só o que o perfil pode acessar.

Teste rápido da API:

```bash
TOKEN=$(curl -s localhost:3333/api/auth/login -H 'Content-Type: application/json' \
  -d '{"email":"admin@distribuierp.local","password":"SENHA_DO_SEED"}' | node -pe 'JSON.parse(require("fs").readFileSync(0)).token')
curl -H "Authorization: Bearer $TOKEN" localhost:3333/api/products
```

## Estado atual (leia antes de usar)

- **Nada foi compilado nem executado ainda.** Ao rodar `npm run build`, podem aparecer ajustes de tipos.
- **Conectadas à API:** login, Fornecedores e Compras. **Ainda com dados mock:** Dashboard, Vendas, PDV, Financeiro e Notas fiscais.
- **Autenticação:** JWT (8h) com perfis ADMIN, GERENTE, VENDEDOR, CAIXA, ESTOQUISTA e FINANCEIRO; todas as rotas exigem login. Limitações: o token fica em `sessionStorage` (prefira cookie httpOnly num BFF em produção), o perfil só é relido ao renovar o token e o limite de tentativas de login é em memória.
- **SEFAZ e adquirentes são mocks** (`backend/src/fiscal.ts`, `sales.ts`). A emissão real exige certificado A1/A3 e homologação.
- Regras fiscais (prazos de cancelamento, CC-e, inutilização, tributação) variam por UF: valide com seu contador.

## Pendências conhecidas

Conectar Dashboard, Vendas, PDV, Financeiro e Fiscal à API · CRUD de usuários e troca de senha · estorno de estoque/financeiro no cancelamento de NF-e · estorno de cartão se a venda falhar · endpoints de OFX/CNAB e webhook PIX · CRUD de usuários e faixas de preço · séries temporais do dashboard · geração de DANFE/XML · testes automatizados.

## Banco gratuito (Neon ou Supabase) e autenticação de servidor

Veja **`docs/BANCO-DE-DADOS.md`**: criar o banco, preencher `DATABASE_URL`/`DIRECT_URL`, `npm run db:push`,
`npm run db:seed`, `npm run db:check`, primeiro acesso (`POST /api/auth/setup`) e a lista de rotas protegidas por perfil.
O seed já cadastra a empresa (CNPJ 69.196.200/0001-68) e a conta Bradesco (ag. 3935-7, c/c 53635-0, chave PIX = CNPJ).

## Emissão fiscal (NFC-e / SEFAZ)

Veja **`docs/FISCAL.md`**: requisitos (certificado A1, credenciamento, CSC), painel de prontidão, matriz fiscal, rotas do servidor,
passo a passo para testar em homologação com a FocusNFe e o que ainda falta. Nada emite nota sem token, certificado e dados fiscais do contador.

import { Body, ConflictException, Controller, ForbiddenException, Delete, Get, Injectable, Param, Patch, Post, Query } from '@nestjs/common';
import { z } from 'zod';
import { AuthUser, Roles } from './auth';
import { CurrentUser, parse } from './common';
import { productToTax } from './fiscal/product-tax';
import { PrismaService } from './prisma.service';

/** MOCK do adquirente. Trocar por SDK real (Stone, PagBank, Mercado Pago) mantendo a mesma assinatura. */
@Injectable()
export class MockAcquirerGateway {
  async charge(_: { acquirerId: string; amount: number; installments: number }) {
    return { approved: true, nsu: String(Date.now()).slice(-8), authCode: Math.random().toString(36).slice(2, 8).toUpperCase() };
  }
}

const CARD = ['DEBITO', 'CREDITO_VISTA', 'CREDITO_PARCELADO'];
const saleSchema = z.object({
  channel: z.enum(['ATACADO', 'VAREJO']), customerId: z.string().uuid().optional(),
  paymentMethod: z.enum(['DINHEIRO', 'PIX', 'DEBITO', 'CREDITO_VISTA', 'CREDITO_PARCELADO', 'BOLETO', 'PRAZO']),
  installments: z.coerce.number().int().min(1).max(12).default(1), discount: z.coerce.number().min(0).default(0),
  dueDate: z.coerce.date().optional(), acquirerId: z.string().uuid().optional(),
  items: z.array(z.object({ productId: z.string().uuid(), quantity: z.coerce.number().positive() })).min(1),
}).superRefine((d, c) => {
  if (d.channel === 'ATACADO' && !d.customerId) c.addIssue({ code: 'custom', path: ['customerId'], message: 'Atacado exige cliente' });
  if (['BOLETO', 'PRAZO'].includes(d.paymentMethod) && !d.dueDate) c.addIssue({ code: 'custom', path: ['dueDate'], message: 'Informe o vencimento' });
  if (CARD.includes(d.paymentMethod) && !d.acquirerId) c.addIssue({ code: 'custom', path: ['acquirerId'], message: 'Informe o adquirente' });
});
const patchSchema = z.object({ customerId: z.string().uuid().optional(), dueDate: z.coerce.date().optional() });

@Injectable()
export class SalesService {
  constructor(private prisma: PrismaService, private gateway: MockAcquirerGateway) {}
  private include = { items: true, invoice: true, customer: true } as const;

  list(channel?: 'ATACADO' | 'VAREJO') { return this.prisma.sale.findMany({ where: { channel }, include: this.include, orderBy: { createdAt: 'desc' }, take: 100 }); }
  one(id: string) { return this.prisma.sale.findUniqueOrThrow({ where: { id }, include: this.include }); }

  async create(body: unknown, userId: string) {
    const d = parse(saleSchema, body);
    // 1) preço: atacado usa a faixa progressiva (maior minQty atingido); varejo usa o preço de balcão
    const products = await this.prisma.product.findMany({ where: { id: { in: d.items.map((i) => i.productId) } }, include: { priceTiers: true } });
    const lines = d.items.map((i) => {
      const p = products.find((x) => x.id === i.productId);
      if (!p) throw new ConflictException(`Produto ${i.productId} não encontrado`);
      const tier = d.channel === 'ATACADO' ? p.priceTiers.filter((t) => Number(t.minQty) <= i.quantity).sort((a, b) => Number(b.minQty) - Number(a.minQty))[0] : undefined;
      return { productId: p.id, quantity: i.quantity, unitPrice: Number(tier?.price ?? p.retailPrice), unitCost: Number(p.avgCost), taxSnapshot: productToTax(p) as any };
    });
    const subtotal = lines.reduce((a, l) => a + l.quantity * l.unitPrice, 0), total = Math.max(subtotal - d.discount, 0);

    // 2) cobrança no cartão (externa, fora da transação). TODO: estornar se a transação abaixo falhar.
    const acq = CARD.includes(d.paymentMethod) ? await this.prisma.acquirer.findUniqueOrThrow({ where: { id: d.acquirerId } }) : null;
    if (acq && !(await this.gateway.charge({ acquirerId: acq.id, amount: total, installments: d.installments })).approved) throw new ConflictException('Pagamento recusado');

    return this.prisma.$transaction(async (tx) => {
      const sale = await tx.sale.create({ data: {
        channel: d.channel, customerId: d.customerId, sellerId: userId, paymentMethod: d.paymentMethod, installments: d.installments,
        subtotal, discount: d.discount, total, dueDate: d.dueDate, status: 'AGUARDANDO_EMISSAO', items: { create: lines },
      } });

      // 3) baixa de estoque por FEFO (lote que vence primeiro sai primeiro); decremento condicional evita saldo negativo
      for (const l of lines) {
        let falta = l.quantity;
        const batches = await tx.stockBatch.findMany({ where: { productId: l.productId, quantity: { gt: 0 }, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] }, orderBy: { expiresAt: { sort: 'asc', nulls: 'last' } } });
        for (const b of batches) {
          if (falta <= 0) break;
          const take = Math.min(falta, Number(b.quantity));
          const r = await tx.stockBatch.updateMany({ where: { id: b.id, quantity: { gte: take } }, data: { quantity: { decrement: take } } });
          if (!r.count) throw new ConflictException('Estoque alterado por outra venda; tente novamente');
          await tx.stockMovement.create({ data: { productId: l.productId, batchId: b.id, type: 'SAIDA', quantity: take, unitCost: b.unitCost, saleId: sale.id, userId, reason: `Venda #${sale.number}` } });
          falta -= take;
        }
        if (falta > 0) throw new ConflictException(`Estoque insuficiente para o produto ${l.productId}`);
      }

      // 4) financeiro: PIX/dinheiro entram pagos; boleto/prazo ficam pendentes; cartão gera uma linha por parcela com a taxa do adquirente
      const n = d.paymentMethod === 'CREDITO_PARCELADO' ? d.installments : 1;
      const pct = acq ? Number(d.paymentMethod === 'DEBITO' ? acq.debitFeePct : d.paymentMethod === 'CREDITO_PARCELADO' ? acq.installmentFeePct : acq.creditFeePct) : 0;
      const parcela = Math.floor((total / n) * 100) / 100;
      for (let i = 0; i < n; i++) {
        const amount = i === n - 1 ? Math.round((total - parcela * (n - 1)) * 100) / 100 : parcela, fee = Math.round(amount * pct) / 100;
        const days = acq ? (d.paymentMethod === 'DEBITO' ? acq.settlementDaysDebit : acq.settlementDaysCredit + 30 * i) : 0;
        const paidNow = ['PIX', 'DINHEIRO'].includes(d.paymentMethod);
        await tx.financialTransaction.create({ data: {
          type: 'RECEITA', description: `Venda #${sale.number}${n > 1 ? ` (${i + 1}/${n})` : ''}`, amount, feeAmount: fee, netAmount: amount - fee,
          dueDate: d.dueDate ?? new Date(Date.now() + days * 864e5), paidAt: paidNow ? new Date() : undefined, status: paidNow ? 'PAGO' : 'PENDENTE',
          method: d.paymentMethod, installment: n > 1 ? i + 1 : undefined, acquirerId: acq?.id, saleId: sale.id,
        } });
      }

      // 5) nota pendente de emissão (NF-e no atacado, NFC-e no varejo)
      const model = d.channel === 'ATACADO' ? 'NFE_55' : 'NFCE_65';
      const last = await tx.invoice.aggregate({ where: { model, series: 1 }, _max: { number: true } });
      await tx.invoice.create({ data: { saleId: sale.id, model, series: 1, number: (last._max.number ?? 0) + 1 } }); // corrida → unique viola → 409; o cliente repete
      return tx.sale.findUniqueOrThrow({ where: { id: sale.id }, include: this.include });
    });
  }

  async update(id: string, body: unknown) {
    const s = await this.one(id);
    if (s.status !== 'AGUARDANDO_EMISSAO') throw new ConflictException('Só vendas aguardando emissão podem ser editadas');
    return this.prisma.sale.update({ where: { id }, data: parse(patchSchema, body), include: this.include }); // TODO: edição de itens = cancelar e refazer a venda
  }

  /** Exclui venda ainda sem nota autorizada e devolve o estoque aos lotes de origem. */
  async remove(id: string) {
    const s = await this.one(id);
    if (s.status !== 'AGUARDANDO_EMISSAO') throw new ConflictException('Venda faturada: cancele a NF-e e registre devolução');
    return this.prisma.$transaction(async (tx) => {
      for (const m of await tx.stockMovement.findMany({ where: { saleId: id, type: 'SAIDA' } }))
        if (m.batchId) await tx.stockBatch.update({ where: { id: m.batchId }, data: { quantity: { increment: m.quantity } } });
      await tx.stockMovement.deleteMany({ where: { saleId: id } });
      await tx.financialTransaction.deleteMany({ where: { saleId: id } });
      await tx.invoice.deleteMany({ where: { saleId: id } });
      await tx.saleItem.deleteMany({ where: { saleId: id } });
      return tx.sale.delete({ where: { id } });
    });
  }
}

@Controller('sales')
@Roles('GERENTE', 'VENDEDOR', 'CAIXA')
export class SalesController {
  constructor(private s: SalesService) {}
  @Get() list(@Query('channel') c?: 'ATACADO' | 'VAREJO') { return this.s.list(c); }
  @Get(':id') one(@Param('id') id: string) { return this.s.one(id); }
  @Post() create(@Body() b: any, @CurrentUser() u: AuthUser) {
    if (u.role === 'CAIXA' && b?.channel !== 'VAREJO') throw new ForbiddenException('O perfil Caixa só registra vendas de varejo');
    return this.s.create(b, u.sub);
  }
  @Patch(':id') update(@Param('id') id: string, @Body() b: unknown) { return this.s.update(id, b); }
  @Roles('GERENTE') @Delete(':id') remove(@Param('id') id: string) { return this.s.remove(id); }
}

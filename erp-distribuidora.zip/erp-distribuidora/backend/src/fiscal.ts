import { Body, ConflictException, Controller, Get, Inject, Injectable, Param, Post, Query, UnprocessableEntityException } from '@nestjs/common';
import { InvoiceStatus } from '@prisma/client';
import { z } from 'zod';
import { Roles } from './auth';
import { parse } from './common';
import { PrismaService } from './prisma.service';

/** Contrato da integração SEFAZ. A implementação real assina o XML com o certificado A1/A3 e transmite ao webservice da UF. */
export abstract class SefazGateway {
  abstract authorize(i: { model: string; series: number; number: number }): Promise<{ accessKey: string; protocol: string; xml: string }>;
  abstract cancel(accessKey: string, reason: string): Promise<{ protocol: string }>;
  abstract correction(accessKey: string, seq: number, text: string): Promise<{ protocol: string }>;
  abstract inutilize(model: string, series: number, from: number, to: number, reason: string): Promise<{ protocol: string }>;
}

const rnd = (n: number) => Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join('');
@Injectable()
export class MockSefazGateway extends SefazGateway {
  async authorize(i: { model: string; series: number; number: number }) {
    const accessKey = `26${rnd(6)}${process.env.COMPANY_CNPJ ?? rnd(14)}${i.model === 'NFE_55' ? '55' : '65'}${String(i.series).padStart(3, '0')}${String(i.number).padStart(9, '0')}${rnd(10)}`.slice(0, 44);
    return { accessKey, protocol: `1${rnd(14)}`, xml: `<NFe><infNFe Id="NFe${accessKey}"/></NFe>` };
  }
  async cancel() { return { protocol: `1${rnd(14)}` }; }
  async correction() { return { protocol: `1${rnd(14)}` }; }
  async inutilize() { return { protocol: `1${rnd(14)}` }; }
}

const reason = z.string().trim().min(15, 'Justificativa deve ter ao menos 15 caracteres').max(255);
const inutSchema = z.object({ model: z.enum(['NFE_55', 'NFCE_65']), series: z.coerce.number().int().min(1), from: z.coerce.number().int().min(1), to: z.coerce.number().int().min(1), reason })
  .refine((d) => d.to >= d.from && d.to - d.from < 500, { path: ['to'], message: 'Faixa inválida (máx. 500 números)' });
const ev = (tipo: string, texto: string, protocolo: string) => ({ tipo, texto, protocolo, em: new Date().toISOString() });

@Controller('fiscal')
@Roles('GERENTE', 'FINANCEIRO')
export class FiscalController {
  constructor(private prisma: PrismaService, @Inject(SefazGateway) private sefaz: SefazGateway) {}
  private events = (i: { events: unknown }) => (Array.isArray(i.events) ? i.events : []);

  @Get('invoices') list(@Query('status') status?: InvoiceStatus) { return this.prisma.invoice.findMany({ where: { status }, include: { sale: { include: { customer: true } } }, orderBy: { createdAt: 'desc' }, take: 100 }); }

  @Post('invoices/:id/emit') async emit(@Param('id') id: string) {
    const inv = await this.prisma.invoice.findUniqueOrThrow({ where: { id } });
    if (!['AGUARDANDO_EMISSAO', 'REJEITADA'].includes(inv.status)) throw new ConflictException('Nota não está apta para emissão');
    try {
      const r = await this.sefaz.authorize(inv);
      return await this.prisma.$transaction(async (tx) => {
        if (inv.saleId) await tx.sale.update({ where: { id: inv.saleId }, data: { status: 'FATURADA' } });
        return tx.invoice.update({ where: { id }, data: { status: 'AUTORIZADA', accessKey: r.accessKey, protocol: r.protocol, xml: r.xml, issuedAt: new Date(), rejectionReason: null, events: [...this.events(inv), ev('Autorização', `Protocolo ${r.protocol}`, r.protocol)] } });
      });
    } catch (e: any) {
      await this.prisma.invoice.update({ where: { id }, data: { status: 'REJEITADA', rejectionReason: String(e?.message ?? 'Rejeição') } });
      throw new UnprocessableEntityException(`SEFAZ rejeitou a nota: ${e?.message}`);
    }
  }

  @Post('invoices/:id/cancel') async cancel(@Param('id') id: string, @Body() b: unknown) {
    const { reason: why } = parse(z.object({ reason }), b);
    const inv = await this.prisma.invoice.findUniqueOrThrow({ where: { id } });
    if (inv.status !== 'AUTORIZADA' || !inv.accessKey) throw new ConflictException('Só notas autorizadas podem ser canceladas');
    const r = await this.sefaz.cancel(inv.accessKey, why); // TODO: validar o prazo legal de cancelamento da UF
    return this.prisma.$transaction(async (tx) => {
      if (inv.saleId) await tx.sale.update({ where: { id: inv.saleId }, data: { status: 'CANCELADA' } }); // TODO: estorno de estoque (devolução) e baixa do financeiro
      return tx.invoice.update({ where: { id }, data: { status: 'CANCELADA', events: [...this.events(inv), ev('Cancelamento', why, r.protocol)] } });
    });
  }

  @Post('invoices/:id/correction') async correction(@Param('id') id: string, @Body() b: unknown) {
    const { text } = parse(z.object({ text: z.string().trim().min(15).max(1000) }), b);
    const inv = await this.prisma.invoice.findUniqueOrThrow({ where: { id } });
    if (inv.status !== 'AUTORIZADA' || !inv.accessKey) throw new ConflictException('Carta de Correção só vale para nota autorizada');
    const evs = this.events(inv) as { tipo: string }[], seq = evs.filter((e) => e.tipo.startsWith('Carta')).length + 1;
    if (seq > 20) throw new ConflictException('Limite de 20 Cartas de Correção por nota');
    const r = await this.sefaz.correction(inv.accessKey, seq, text);
    return this.prisma.invoice.update({ where: { id }, data: { events: [...evs, ev(`Carta de Correção nº ${seq}`, text, r.protocol)] } });
  }

  @Post('inutilize') async inutilize(@Body() b: unknown) {
    const d = parse(inutSchema, b);
    const used = await this.prisma.invoice.findFirst({ where: { model: d.model, series: d.series, number: { gte: d.from, lte: d.to } } });
    if (used) throw new ConflictException(`O número ${used.number} já foi utilizado e não pode ser inutilizado`);
    const r = await this.sefaz.inutilize(d.model, d.series, d.from, d.to, d.reason);
    const rows = Array.from({ length: d.to - d.from + 1 }, (_, i) => ({ model: d.model, series: d.series, number: d.from + i, status: 'INUTILIZADA' as const, protocol: r.protocol, events: [ev('Inutilização', d.reason, r.protocol)] }));
    await this.prisma.invoice.createMany({ data: rows });
    return { inutilizados: rows.length, protocol: r.protocol };
  }
}

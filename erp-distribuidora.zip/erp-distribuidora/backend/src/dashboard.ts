import { Controller, Get, Injectable } from '@nestjs/common';
import { Roles } from './auth';
import { PrismaService } from './prisma.service';

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}
  async summary() {
    const now = new Date(), in30 = new Date(Date.now() + 30 * 864e5), since = new Date(now.getFullYear(), now.getMonth() - 5, 1);
    const open = { status: { in: ['PENDENTE', 'ATRASADO'] as ('PENDENTE' | 'ATRASADO')[] } };
    const sumNet = (type: 'RECEITA' | 'DESPESA', extra = {}) => this.prisma.financialTransaction.aggregate({ _sum: { netAmount: true }, where: { type, ...open, ...extra } });
    const [items, belowMin, expiring, receivable, payable, overdue, byChannel] = await Promise.all([
      this.prisma.stockBatch.aggregate({ _sum: { quantity: true } }),
      this.prisma.$queryRaw<{ n: bigint }[]>`SELECT count(*) AS n FROM products p WHERE p.active AND COALESCE((SELECT sum(b.quantity) FROM stock_batches b WHERE b."productId" = p.id), 0) < p."minStock"`,
      this.prisma.stockBatch.count({ where: { quantity: { gt: 0 }, expiresAt: { lte: in30 } } }),
      sumNet('RECEITA'), sumNet('DESPESA'), sumNet('RECEITA', { dueDate: { lt: now } }),
      this.prisma.sale.groupBy({ by: ['channel'], _sum: { total: true }, where: { status: { not: 'CANCELADA' }, createdAt: { gte: since } } }),
    ]);
    const rec = Number(receivable._sum.netAmount ?? 0), late = Number(overdue._sum.netAmount ?? 0);
    return {
      stock: { totalItems: Number(items._sum.quantity ?? 0), belowMinimum: Number(belowMin[0]?.n ?? 0), expiringIn30Days: expiring },
      finance: { receivable: rec, payable: Number(payable._sum.netAmount ?? 0), delinquencyRate: rec ? (late / rec) * 100 : 0 },
      revenueByChannel: byChannel.map((c) => ({ channel: c.channel, total: Number(c._sum.total ?? 0) })),
      // TODO: séries mensais/semanais de entrada×saída e fluxo de caixa projetado (groupBy por date_trunc)
    };
  }
}

@Controller('dashboard')
@Roles('GERENTE', 'FINANCEIRO')
export class DashboardController {
  constructor(private s: DashboardService) {}
  @Get() summary() { return this.s.summary(); }
}

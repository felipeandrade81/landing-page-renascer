import { BadRequestException, Body, CanActivate, Controller, ExecutionContext, ForbiddenException, Get, HttpException, Injectable, Patch, Post, Req, SetMetadata, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { Prisma, Role } from '@prisma/client';
import { randomBytes, scryptSync, timingSafeEqual } from 'crypto';
import { z } from 'zod';
import { PrismaService } from './prisma.service';

export type AuthUser = { sub: string; role: Role; name: string };
export const Public = () => SetMetadata('isPublic', true);
/** Perfis permitidos (ADMIN sempre passa). Sem @Roles = qualquer usuário autenticado. O método sobrescreve a classe. */
export const Roles = (...roles: Role[]) => SetMetadata('roles', roles);

export const pwSchema = z.string().min(8, 'A senha deve ter ao menos 8 caracteres')
  .refine((p) => /[A-Za-z]/.test(p) && /\d/.test(p), 'Use letras e números na senha');

// Senhas guardadas como "salt:hash" (scrypt). Nunca em texto.
export function hashPassword(pw: string) { const salt = randomBytes(16).toString('hex'); return `${salt}:${scryptSync(pw, salt, 32).toString('hex')}`; }
export function verifyPassword(pw: string, stored: string) {
  const [salt = '', hash = ''] = stored.split(':');
  const expected = Buffer.from(hash, 'hex'), actual = scryptSync(pw, salt, 32);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
const DUMMY = `${'0'.repeat(32)}:${'0'.repeat(64)}`;

/** Guard global: exige token em toda rota (exceto @Public) e confere perfil e status NO BANCO a cada requisição
 *  (desativar um usuário ou mudar o perfil dele vale imediatamente, sem esperar o token expirar). */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private jwt: JwtService, private reflector: Reflector, private prisma: PrismaService) {}
  async canActivate(ctx: ExecutionContext) {
    const targets = [ctx.getHandler(), ctx.getClass()];
    if (this.reflector.getAllAndOverride<boolean>('isPublic', targets)) return true;
    const req = ctx.switchToHttp().getRequest();
    const h: string | undefined = req.headers.authorization;
    if (!h?.startsWith('Bearer ')) throw new UnauthorizedException('Faça login para continuar');
    let sub: string;
    try { sub = (await this.jwt.verifyAsync<AuthUser>(h.slice(7))).sub; } catch { throw new UnauthorizedException('Sessão expirada ou inválida'); }
    const u = await this.prisma.user.findUnique({ where: { id: sub }, select: { id: true, name: true, role: true, active: true } });
    if (!u || !u.active) throw new UnauthorizedException('Usuário inativo ou removido');
    req.user = { sub: u.id, role: u.role, name: u.name } satisfies AuthUser;
    const roles = this.reflector.getAllAndOverride<Role[]>('roles', targets) ?? [];
    if (roles.length && u.role !== 'ADMIN' && !roles.includes(u.role)) throw new ForbiddenException('Seu perfil não tem permissão para esta ação');
    return true;
  }
}

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });
const setupSchema = z.object({ name: z.string().trim().min(3, 'Informe o nome'), email: z.string().email('E-mail inválido'), password: pwSchema });
const changeSchema = z.object({ current: z.string().min(1), next: pwSchema });

@Injectable()
export class AuthService {
  private fails = new Map<string, { n: number; until: number }>(); // TODO: Redis/throttler se rodar em mais de uma instância
  constructor(private prisma: PrismaService, private jwt: JwtService) {}

  private async session(u: { id: string; name: string; email: string; role: Role }) {
    const token = await this.jwt.signAsync({ sub: u.id, role: u.role, name: u.name } satisfies AuthUser);
    return { token, user: { id: u.id, name: u.name, email: u.email, role: u.role } };
  }
  private log(userId: string | null, userName: string, action: string) {
    return this.prisma.auditLog.create({ data: { userId, userName, action } }).catch(() => undefined);
  }

  /** O front consulta isto para saber se mostra "Primeiro acesso" (criar administrador) ou "Entrar". */
  async status() { return { needsSetup: (await this.prisma.user.count()) === 0 }; }

  /** Cria o PRIMEIRO administrador. Só funciona enquanto não existir nenhum usuário (transação serializável evita corrida). */
  async setup(body: unknown) {
    const r = setupSchema.safeParse(body);
    if (!r.success) throw new BadRequestException(r.error.flatten());
    const user = await this.prisma.$transaction(async (tx) => {
      if ((await tx.user.count()) > 0) throw new ForbiddenException('O sistema já foi configurado');
      return tx.user.create({ data: { name: r.data.name, email: r.data.email.toLowerCase(), password: hashPassword(r.data.password), role: 'ADMIN' } });
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    await this.log(user.id, user.name, 'Administrador inicial criado');
    return this.session(user);
  }

  async login(body: unknown, ip: string) {
    const parsed = loginSchema.safeParse(body);
    if (!parsed.success) throw new UnauthorizedException('E-mail ou senha inválidos');
    const email = parsed.data.email.toLowerCase(), key = `${ip}|${email}`, f = this.fails.get(key), now = Date.now();
    if (f && f.n >= 5 && f.until > now) throw new HttpException('Muitas tentativas. Aguarde alguns minutos e tente de novo.', 429);
    const user = await this.prisma.user.findUnique({ where: { email } });
    const ok = verifyPassword(parsed.data.password, user?.password ?? DUMMY) && !!user?.active; // sempre roda o scrypt (não revela se o e-mail existe)
    if (!ok || !user) {
      if (this.fails.size > 5000) this.fails.clear();
      this.fails.set(key, { n: (f && f.until > now ? f.n : 0) + 1, until: now + 15 * 60_000 });
      throw new UnauthorizedException('E-mail ou senha inválidos');
    }
    this.fails.delete(key);
    await this.prisma.user.update({ where: { id: user.id }, data: { lastLogin: new Date() } });
    await this.log(user.id, user.name, 'Login');
    return this.session(user);
  }

  async me(id: string) {
    const u = await this.prisma.user.findUnique({ where: { id } });
    if (!u?.active) throw new UnauthorizedException('Usuário inativo');
    return { id: u.id, name: u.name, email: u.email, role: u.role };
  }

  async changePassword(id: string, body: unknown) {
    const r = changeSchema.safeParse(body);
    if (!r.success) throw new BadRequestException(r.error.flatten());
    const u = await this.prisma.user.findUniqueOrThrow({ where: { id } });
    if (!verifyPassword(r.data.current, u.password)) throw new UnauthorizedException('Senha atual incorreta');
    await this.prisma.user.update({ where: { id }, data: { password: hashPassword(r.data.next) } });
    await this.log(u.id, u.name, 'Senha alterada');
    return { ok: true };
  }
}

@Controller('auth')
export class AuthController {
  constructor(private s: AuthService) {}
  @Public() @Get('status') status() { return this.s.status(); }
  @Public() @Post('setup') setup(@Body() b: unknown) { return this.s.setup(b); }
  @Public() @Post('login') login(@Body() b: unknown, @Req() req: any) { return this.s.login(b, req.ip); }
  @Get('me') me(@Req() req: { user: AuthUser }) { return this.s.me(req.user.sub); }
  @Patch('password') password(@Body() b: unknown, @Req() req: { user: AuthUser }) { return this.s.changePassword(req.user.sub, b); }
}

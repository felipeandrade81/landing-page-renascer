import { ArgumentsHost, BadRequestException, Body, Catch, Controller, createParamDecorator, Delete, ExceptionFilter, ExecutionContext, Get, Inject, NotFoundException, Param, Patch, Post, Query } from '@nestjs/common';
import { Prisma, Role } from '@prisma/client';
import { AuthUser, Roles } from './auth';
import { AnyZodObject, ZodTypeAny, z } from 'zod';
import { PrismaService } from './prisma.service';

export function parse<T extends ZodTypeAny>(schema: T, data: unknown): z.infer<T> {
  const r = schema.safeParse(data);
  if (!r.success) throw new BadRequestException(r.error.flatten());
  return r.data;
}

export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext) => ctx.switchToHttp().getRequest().user as AuthUser);
export const UserId = createParamDecorator((_: unknown, ctx: ExecutionContext) => (ctx.switchToHttp().getRequest().user as AuthUser).sub);

@Catch(Prisma.PrismaClientKnownRequestError)
export class PrismaExceptionFilter implements ExceptionFilter {
  catch(e: Prisma.PrismaClientKnownRequestError, host: ArgumentsHost) {
    const map: Record<string, [number, string]> = {
      P2002: [409, 'Já existe um registro com este valor único'], P2025: [404, 'Registro não encontrado'], P2003: [409, 'Existem registros vinculados a este item'],
    };
    const [status, message] = map[e.code] ?? [500, 'Erro de banco de dados'];
    host.switchToHttp().getResponse().status(status).json({ statusCode: status, message, code: e.code });
  }
}

/** Gera um controller REST completo (GET lista/id, POST, PATCH, DELETE) para um model do Prisma. */
export function crud(path: string, model: string, schema: AnyZodObject, opt: { search?: string[]; orderBy?: object; include?: object; read?: Role[]; write?: Role[] } = {}) {
  @Controller(path)
  class CrudController {
    constructor(@Inject(PrismaService) private readonly prisma: PrismaService) {}
    private get d() { return (this.prisma as any)[model]; }

    @Roles(...(opt.read ?? [])) @Get() list(@Query('q') q?: string, @Query('take') take = '50', @Query('skip') skip = '0') {
      const where = q && opt.search?.length ? { OR: opt.search.map((f) => ({ [f]: { contains: q, mode: 'insensitive' } })) } : {};
      return this.d.findMany({ where, take: Math.min(+take || 50, 200), skip: +skip || 0, orderBy: opt.orderBy ?? { createdAt: 'desc' }, include: opt.include });
    }
    @Roles(...(opt.read ?? [])) @Get(':id') async one(@Param('id') id: string) {
      const row = await this.d.findUnique({ where: { id }, include: opt.include });
      if (!row) throw new NotFoundException('Registro não encontrado');
      return row;
    }
    @Roles(...(opt.write ?? [])) @Post() create(@Body() body: unknown) { return this.d.create({ data: parse(schema, body) }); }
    @Roles(...(opt.write ?? [])) @Patch(':id') update(@Param('id') id: string, @Body() body: unknown) { return this.d.update({ where: { id }, data: parse(schema.partial(), body) }); }
    @Roles(...(opt.write ?? [])) @Delete(':id') remove(@Param('id') id: string) { return this.d.delete({ where: { id } }); }
  }
  return CrudController;
}

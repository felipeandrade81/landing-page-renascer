import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { JwtModule } from '@nestjs/jwt';
import { AuthController, AuthGuard, AuthService } from './auth';
import { DashboardController, DashboardService } from './dashboard';
import { FiscalNfceController, FiscalNfceService } from './fiscal/fiscal-nfce';
import { FiscalController, MockSefazGateway, SefazGateway } from './fiscal';
import { PrismaService } from './prisma.service';
import { PurchasesController, PurchasesService } from './purchases';
import { AuditController, BankController, CompanyController, WhatsappController } from './settings';
import { AuthorizeController, UsersController } from './users';
import { AcquirersController, CustomersController, ProductsController, SuppliersController, TransactionsController } from './resources';
import { MockAcquirerGateway, SalesController, SalesService } from './sales';

const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) throw new Error('Defina JWT_SECRET no .env (mínimo 32 caracteres). Gere com: openssl rand -base64 48');

@Module({
  imports: [JwtModule.register({ global: true, secret, signOptions: { expiresIn: '8h' } })],
  controllers: [AuthController, UsersController, AuthorizeController, CompanyController, BankController, WhatsappController, AuditController, SuppliersController, ProductsController, CustomersController, TransactionsController, AcquirersController, PurchasesController, SalesController, FiscalController, FiscalNfceController, DashboardController],
  providers: [
    PrismaService, FiscalNfceService, AuthService, PurchasesService, SalesService, DashboardService, MockAcquirerGateway,
    { provide: SefazGateway, useClass: MockSefazGateway },
    { provide: APP_GUARD, useClass: AuthGuard }, // todas as rotas exigem login
  ],
})
export class AppModule {}

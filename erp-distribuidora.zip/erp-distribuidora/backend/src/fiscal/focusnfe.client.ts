// Cliente HTTP da FocusNFe (NFC-e). Sem dependências do Nest: usa o fetch nativo do Node 18+.
// Autenticação: HTTP Basic com o TOKEN como usuário e senha vazia. Homologação e produção usam endereços e tokens diferentes.
export type FocusEnv = 'homologacao' | 'producao';
export type FocusState = 'autorizada' | 'processando' | 'rejeitada' | 'cancelada' | 'erro';
export type FocusResult = {
  state: FocusState; httpStatus: number; message: string; key?: string; number?: string; series?: string; protocol?: string;
  qrcodeUrl?: string; danfeUrl?: string; xmlUrl?: string; raw: unknown;
};
export const FOCUS_BASE: Record<FocusEnv, string> = { homologacao: 'https://homologacao.focusnfe.com.br', producao: 'https://api.focusnfe.com.br' };

/** Converte a resposta da API no nosso formato. Tolerante: campos ausentes viram undefined. */
export function normalizeFocus(httpStatus: number, body: any, base: string): FocusResult {
  const abs = (p?: string) => (!p ? undefined : /^https?:\/\//.test(p) ? p : base + p);
  const st = String(body?.status ?? '');
  let state: FocusState = 'erro';
  if (st === 'autorizado') state = 'autorizada';
  else if (st === 'processando_autorizacao') state = 'processando';
  else if (st === 'erro_autorizacao' || st === 'rejeitado' || st === 'denegado') state = 'rejeitada';
  else if (st === 'cancelado') state = 'cancelada';
  const erros = Array.isArray(body?.erros) ? body.erros.map((e: any) => e?.mensagem).filter(Boolean).join('; ') : '';
  const message = String(body?.mensagem_sefaz || body?.mensagem || erros || st || `HTTP ${httpStatus}`);
  return {
    state, httpStatus, message, key: body?.chave_nfe, number: body?.numero != null ? String(body.numero) : undefined, series: body?.serie != null ? String(body.serie) : undefined,
    protocol: body?.protocolo ?? body?.numero_protocolo, qrcodeUrl: body?.qrcode_url, danfeUrl: abs(body?.caminho_danfe), xmlUrl: abs(body?.caminho_xml_nota_fiscal), raw: body,
  };
}

export class FocusNfeClient {
  constructor(private token: string, private env: FocusEnv, private fetchImpl: typeof fetch = (...a) => fetch(...a), private timeoutMs = 25000) {
    if (!token) throw new Error('Token da FocusNFe não configurado');
  }
  get base() { return FOCUS_BASE[this.env]; }
  private async call(method: string, path: string, body?: unknown): Promise<FocusResult> {
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), this.timeoutMs);
    try {
      const res = await this.fetchImpl(this.base + path, {
        method, signal: ctl.signal, body: body === undefined ? undefined : JSON.stringify(body),
        headers: { Authorization: 'Basic ' + Buffer.from(this.token + ':').toString('base64'), 'Content-Type': 'application/json' },
      });
      const json = await res.json().catch(() => ({}));
      return normalizeFocus(res.status, json, this.base);
    } catch (e: any) {
      return { state: 'erro', httpStatus: 0, message: e?.name === 'AbortError' ? 'A FocusNFe não respondeu a tempo' : `Falha de rede: ${e?.message ?? e}`, raw: null };
    } finally { clearTimeout(timer); }
  }
  /** Envia a NFC-e. A "ref" identifica a nota: reenviar com a mesma ref NÃO duplica. */
  emitNfce(ref: string, payload: unknown) { return this.call('POST', `/v2/nfce?ref=${encodeURIComponent(ref)}`, payload); }
  getNfce(ref: string) { return this.call('GET', `/v2/nfce/${encodeURIComponent(ref)}`); }
  cancelNfce(ref: string, justificativa: string) { return this.call('DELETE', `/v2/nfce/${encodeURIComponent(ref)}`, { justificativa }); }
}

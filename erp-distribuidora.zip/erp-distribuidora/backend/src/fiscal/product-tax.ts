import { TaxData } from './fiscal-core';
/** Converte um produto do banco na matriz fiscal usada pelo núcleo. */
export const productToTax = (p: any): TaxData => ({
  ncm: p.ncm ?? undefined, cest: p.cest ?? undefined, unidade: p.unit ?? undefined, origem: p.origin ?? undefined, cfop: p.cfop ?? undefined, cst: p.cst ?? undefined,
  credSnAliq: p.credSnRate != null ? Number(p.credSnRate) : undefined, icmsAliq: p.icmsRate != null ? Number(p.icmsRate) : undefined,
  pisCst: p.pisCst ?? undefined, pisAliq: p.pisRate != null ? Number(p.pisRate) : undefined, cofinsCst: p.cofinsCst ?? undefined, cofinsAliq: p.cofinsRate != null ? Number(p.cofinsRate) : undefined,
});

import { BadRequestException, Body, ConflictException, Controller, Delete, Get, Injectable, Param, Patch, Post, Query } from '@nestjs/common';
import { Prisma, PurchaseStatus, Role } from '@prisma/client';
import { XMLParser } from 'fast-xml-parser';
import { z } from 'zod';
import { Roles } from './auth';
import { parse, UserId } from './common';
import { PrismaService } from './prisma.service';

const itemSchema = z.object({ productId: z.string().uuid(), quantity: z.coerce.number().positive(), unitCost: z.coerce.number().positive() });
const purchaseSchema = z.object({ supplierId: z.string().uuid(), expectedAt: z.coerce.date().optional(), items: z.array(itemSchema).min(1) });
const receiveSchema = z.object({ lots: z.array(z.object({ productId: z.string().uuid(), lotCode: z.string().min(1), expiresAt: z.coerce.date().optional() })).default([]) });
const sum = (items: { quantity: number; unitCost: number }[]) => items.reduce((a, i) => a + i.quantity * i.unitCost, 0);

@Injectable()
export class PurchasesService {
  constructor(private prisma: PrismaService) {}
  private include = { items: true, supplier: true } as const;

  list(status?: PurchaseStatus) { return this.prisma.purchase.findMany({ where: { status }, include: this.include, orderBy: { createdAt: 'desc' } }); }
  one(id: string) { return this.prisma.purchase.findUniqueOrThrow({ where: { id }, include: this.include }); }

  create(body: unknown, userId: string) {
    const d = parse(purchaseSchema, body);
    return this.prisma.purchase.create({ data: { supplierId: d.supplierId, expectedAt: d.expectedAt, total: sum(d.items), createdById: userId, items: { create: d.items } }, include: this.include });
  }

  async update(id: string, body: unknown) {
    const d = parse(purchaseSchema, body);
    return this.prisma.$transaction(async (tx) => {
      const p = await tx.purchase.findUniqueOrThrow({ where: { id } });
      if (!(['RASCUNHO', 'PENDENTE_APROVACAO', 'APROVADO'] as PurchaseStatus[]).includes(p.status)) throw new ConflictException('Pedido recebido ou cancelado não pode ser alterado');
      await tx.purchaseItem.deleteMany({ where: { purchaseId: id } });
      return tx.purchase.update({ where: { id }, include: this.include, data: {
        supplierId: d.supplierId, expectedAt: d.expectedAt, total: sum(d.items), items: { create: d.items },
        status: p.status === 'APROVADO' ? 'PENDENTE_APROVACAO' : p.status, // alterou depois de aprovado → reaprovar
      } });
    });
  }

  /** Transição atômica de status (evita aprovar/receber duas vezes em requisições concorrentes). */
  async move(id: string, from: PurchaseStatus[], to: PurchaseStatus, extra: Prisma.PurchaseUncheckedUpdateManyInput = {}, db: Prisma.TransactionClient | PrismaService = this.prisma) {
    const r = await db.purchase.updateMany({ where: { id, status: { in: from } }, data: { status: to, ...extra } });
    if (!r.count) throw new ConflictException(`Transição inválida para ${to}`);
  }
  submit(id: string) { return this.move(id, ['RASCUNHO'], 'PENDENTE_APROVACAO'); }
  approve(id: string, userId: string) { return this.move(id, ['PENDENTE_APROVACAO'], 'APROVADO', { approvedById: userId }); }
  cancel(id: string) { return this.move(id, ['PENDENTE_APROVACAO', 'APROVADO'], 'CANCELADO'); }

  /** Recebimento: entrada por lote (FEFO), custo médio ponderado, movimento de estoque e conta a pagar. */
  async receive(id: string, userId: string, body: unknown = {}) {
    const { lots } = parse(receiveSchema, body);
    return this.prisma.$transaction(async (tx) => {
      await this.move(id, ['APROVADO'], 'RECEBIDO', { receivedAt: new Date() }, tx);
      const p = await tx.purchase.findUniqueOrThrow({ where: { id }, include: { items: true } });
      for (const it of p.items) {
        const qty = Number(it.quantity), cost = Number(it.unitCost);
        const prod = await tx.product.findUniqueOrThrow({ where: { id: it.productId } });
        const stock = Number((await tx.stockBatch.aggregate({ where: { productId: it.productId }, _sum: { quantity: true } }))._sum.quantity ?? 0);
        const avg = (stock * Number(prod.avgCost) + qty * cost) / (stock + qty);
        await tx.product.update({ where: { id: it.productId }, data: { avgCost: avg, replacementCost: cost } });
        const lot = lots.find((l) => l.productId === it.productId);
        const lotCode = lot?.lotCode ?? `P${p.number}`;
        const expiresAt = lot?.expiresAt ?? (prod.shelfLifeDays ? new Date(Date.now() + prod.shelfLifeDays * 864e5) : null);
        const batch = await tx.stockBatch.upsert({
          where: { productId_lotCode: { productId: it.productId, lotCode } },
          create: { productId: it.productId, lotCode, expiresAt, quantity: qty, unitCost: cost }, update: { quantity: { increment: qty } },
        });
        await tx.stockMovement.create({ data: { productId: it.productId, batchId: batch.id, type: 'ENTRADA', quantity: qty, unitCost: cost, purchaseId: id, userId, reason: `Compra #${p.number}` } });
      }
      await tx.financialTransaction.create({ data: { type: 'DESPESA', description: `Compra #${p.number}`, amount: p.total, netAmount: p.total, dueDate: new Date(Date.now() + 30 * 864e5), purchaseId: id } }); // TODO: prazo vem de supplier.paymentTerms
      return tx.purchase.findUniqueOrThrow({ where: { id }, include: this.include });
    });
  }

  /** Importa o XML da NF-e de entrada: cria o pedido, dá entrada e atualiza custos. */
  async importXml(xml: string, userId: string) {
    const x = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', parseTagValue: false }).parse(xml);
    const inf = x?.nfeProc?.NFe?.infNFe ?? x?.NFe?.infNFe;
    if (!inf) throw new BadRequestException('XML não é uma NF-e válida (infNFe ausente)');
    const key = String(inf['@_Id']).replace('NFe', '');
    const supplier = await this.prisma.supplier.findUnique({ where: { cnpj: String(inf.emit.CNPJ) } });
    if (!supplier) throw new BadRequestException(`Fornecedor ${inf.emit.CNPJ} não cadastrado`);
    const items: { productId: string; quantity: number; unitCost: number }[] = [], ignored: string[] = [];
    for (const d of ([] as any[]).concat(inf.det)) {
      const link = await this.prisma.productSupplier.findFirst({ where: { supplierId: supplier.id, supplierSku: d.prod.cProd } });
      const product = link ? { id: link.productId } : await this.prisma.product.findFirst({ where: { OR: [{ sku: d.prod.cProd }, { barcode: d.prod.cEAN }] }, select: { id: true } });
      if (product) items.push({ productId: product.id, quantity: parseFloat(d.prod.qCom), unitCost: parseFloat(d.prod.vUnCom) });
      else ignored.push(`${d.prod.cProd} – ${d.prod.xProd}`);
    }
    if (!items.length) throw new BadRequestException({ message: 'Nenhum item do XML corresponde a produtos cadastrados', ignored });
    const p = await this.prisma.purchase.create({ data: { supplierId: supplier.id, status: 'APROVADO', total: sum(items), nfeXmlKey: key, nfeXml: xml, createdById: userId, items: { create: items } } }); // chave duplicada → 409
    // TODO: manifestação do destinatário (evento 210200) via SefazGateway
    return { purchase: await this.receive(p.id, userId), ignored };
  }

  async remove(id: string) {
    const p = await this.prisma.purchase.findUniqueOrThrow({ where: { id } });
    if (p.status === 'RECEBIDO') throw new ConflictException('Pedido recebido já movimentou estoque e financeiro; faça uma devolução');
    return this.prisma.purchase.delete({ where: { id } });
  }
}

const OP: Role[] = ['GERENTE', 'ESTOQUISTA'], MGR: Role[] = ['GERENTE'];

@Controller('purchases')
@Roles(...OP)
export class PurchasesController {
  constructor(private s: PurchasesService) {}
  @Get() list(@Query('status') status?: PurchaseStatus) { return this.s.list(status); }
  @Get(':id') one(@Param('id') id: string) { return this.s.one(id); }
  @Post() create(@Body() b: unknown, @UserId() u: string) { return this.s.create(b, u); }
  @Patch(':id') update(@Param('id') id: string, @Body() b: unknown) { return this.s.update(id, b); }
  @Post(':id/submit') submit(@Param('id') id: string) { return this.s.submit(id); }
  @Roles(...MGR) @Post(':id/approve') approve(@Param('id') id: string, @UserId() u: string) { return this.s.approve(id, u); }
  @Roles(...MGR) @Post(':id/cancel') cancel(@Param('id') id: string) { return this.s.cancel(id); }
  @Post(':id/receive') receive(@Param('id') id: string, @Body() b: unknown, @UserId() u: string) { return this.s.receive(id, u, b); }
  @Post('import-xml') importXml(@Body() b: { xml?: string }, @UserId() u: string) { return this.s.importXml(String(b?.xml ?? ''), u); }
  @Roles(...MGR) @Delete(':id') remove(@Param('id') id: string) { return this.s.remove(id); }
}

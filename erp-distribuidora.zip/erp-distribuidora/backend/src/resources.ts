import type { Role } from '@prisma/client';
import { z } from 'zod';
import { crud } from './common';

const num = z.coerce.number().min(0);
const digits = (n: number, msg: string) => z.string().transform((v) => v.replace(/\D/g, '')).refine((v) => v.length === n, msg);

export const supplierSchema = z.object({
  legalName: z.string().min(3), tradeName: z.string().optional(), cnpj: digits(14, 'CNPJ deve ter 14 dígitos'),
  stateRegistration: z.string().optional(), address: z.record(z.any()).optional(), phones: z.array(z.string()).default([]),
  orderEmail: z.string().email().optional(), paymentTerms: z.string().optional(), active: z.boolean().default(true),
});
export const productSchema = z.object({
  sku: z.string().min(1), barcode: z.string().optional(), name: z.string().min(2), category: z.string().min(1), unit: z.string().default('UN'),
  unitsPerBox: z.coerce.number().int().min(1).default(1), boxesPerPallet: z.coerce.number().int().optional(), sellsByWeight: z.boolean().default(false),
  ncm: digits(8, 'NCM deve ter 8 dígitos'), cfop: z.string().regex(/^5\d{3}$/, 'CFOP de venda no estado (5xxx)').optional(),
  cest: z.string().regex(/^\d{7}$/).optional(), origin: z.string().regex(/^[0-8]$/).default('0'), cst: z.string().regex(/^\d{2,3}$/).optional(),
  credSnRate: z.coerce.number().min(0).max(100).optional(), icmsRate: z.coerce.number().min(0).max(100).optional(),
  pisCst: z.string().regex(/^\d{2}$/).optional(), pisRate: z.coerce.number().min(0).max(100).optional(), cofinsCst: z.string().regex(/^\d{2}$/).optional(), cofinsRate: z.coerce.number().min(0).max(100).optional(),
  shelfLifeDays: z.coerce.number().int().optional(),
  minStock: num.default(0), criticalStock: num.default(0), retailPrice: z.coerce.number().positive(), active: z.boolean().default(true),
}); // avgCost/replacementCost só mudam por compras (não são editáveis aqui)
export const customerSchema = z.object({
  name: z.string().min(2), document: z.string().optional(), email: z.string().email().optional(), phone: z.string().optional(),
  creditLimit: num.default(0), address: z.record(z.any()).optional(),
});
export const transactionSchema = z.object({
  type: z.enum(['RECEITA', 'DESPESA']), description: z.string().min(3), amount: z.coerce.number().positive(), feeAmount: num.default(0),
  netAmount: z.coerce.number().positive(), dueDate: z.coerce.date(), paidAt: z.coerce.date().optional(),
  status: z.enum(['PENDENTE', 'PAGO', 'ATRASADO', 'CANCELADO']).default('PENDENTE'),
  method: z.enum(['DINHEIRO', 'PIX', 'DEBITO', 'CREDITO_VISTA', 'CREDITO_PARCELADO', 'BOLETO', 'PRAZO']).optional(),
});
export const acquirerSchema = z.object({
  name: z.string().min(2), debitFeePct: z.coerce.number().min(0).max(30), creditFeePct: z.coerce.number().min(0).max(30),
  installmentFeePct: z.coerce.number().min(0).max(30), anticipationFeePct: z.coerce.number().min(0).max(30),
  settlementDaysDebit: z.coerce.number().int().min(0).default(1), settlementDaysCredit: z.coerce.number().int().min(0).default(30),
});

const r = (...x: Role[]) => x; // ADMIN sempre tem acesso; [] = qualquer usuário autenticado
export const SuppliersController = crud('suppliers', 'supplier', supplierSchema, { search: ['legalName', 'tradeName', 'cnpj'], read: r('GERENTE', 'ESTOQUISTA'), write: r('GERENTE'), include: { _count: { select: { products: true, purchases: true } } } });
export const ProductsController = crud('products', 'product', productSchema, { search: ['name', 'sku', 'barcode'], read: r(), write: r('GERENTE', 'ESTOQUISTA'), include: { priceTiers: true, batches: { select: { quantity: true } } } });
export const CustomersController = crud('customers', 'customer', customerSchema, { search: ['name', 'document'], read: r('GERENTE', 'VENDEDOR', 'CAIXA'), write: r('GERENTE', 'VENDEDOR') });
export const TransactionsController = crud('finance/transactions', 'financialTransaction', transactionSchema, { search: ['description'], read: r('GERENTE', 'FINANCEIRO'), write: r('GERENTE', 'FINANCEIRO') });
export const AcquirersController = crud('finance/acquirers', 'acquirer', acquirerSchema, { orderBy: { name: 'asc' }, read: r(), write: r('GERENTE', 'FINANCEIRO') });

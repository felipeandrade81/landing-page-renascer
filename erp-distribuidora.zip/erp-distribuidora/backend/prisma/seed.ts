import { PrismaClient } from '@prisma/client';
import { randomBytes, scryptSync } from 'crypto';

const prisma = new PrismaClient();
const days = (n: number) => new Date(Date.now() + n * 864e5);
const hash = (pw: string) => { const salt = randomBytes(16).toString('hex'); return `${salt}:${scryptSync(pw, salt, 32).toString('hex')}`; };

async function main() {
  // Empresa: dados do Cartão CNPJ emitido em 18/09/2026
  await prisma.company.upsert({
    where: { id: 'main' }, update: {},
    create: {
      id: 'main', legalName: 'RENASCER DISTRIBUIDORA DE ALIMENTOS LTDA', tradeName: 'RENASCER DISTRIBUIDORA DE ALIMENTOS', cnpj: '69196200000168',
      size: 'EPP', legalNature: '206-2 – Sociedade Empresária Limitada', status: 'Ativa desde 17/09/2026 (matriz)',
      cnae: '46.34-6-99 – Comércio atacadista de carnes e derivados de outros animais',
      cnaesSecondary: '46.34-6-01 Carnes bovinas e suínas e derivados · 46.34-6-02 Aves abatidas e derivados · 47.21-1-03 Varejista de laticínios e frios · 47.22-9-01 Varejista de carnes (açougues)',
      address: 'Av. Piracicaba, 584 – Jardim São Paulo – Recife/PE – CEP 50.790-205', street: 'Av. Piracicaba', streetNumber: '584', district: 'Jardim São Paulo', city: 'Recife', uf: 'PE', zip: '50790205', email: 'renascer.distribuidora2026@gmail.com', phone: '(81) 3333-3333', openedAt: new Date('2026-09-17'),
    },
  });

  // Conta bancária da empresa: o PIX do PDV usa a chave CNPJ
  await prisma.bankAccount.upsert({
    where: { bankName_agency_account: { bankName: '237 – Bradesco', agency: '3935-7', account: '53635-0' } }, update: {},
    create: { bankName: '237 – Bradesco', agency: '3935-7', account: '53635-0', accountType: 'Corrente', holderName: 'RENASCER DISTRIBUIDORA DE ALIMENTOS LTDA', holderCnpj: '69196200000168', pixKeyType: 'CNPJ', pixKey: '69196200000168', isPrimary: true },
  });

  // WhatsApp do gerente (aviso de cancelamentos)
  await prisma.whatsappContact.upsert({ where: { phone: '5581998596805' }, update: {}, create: { name: 'Gerente', phone: '5581998596805' } });

  // Administrador opcional: defina SEED_ADMIN_EMAIL e SEED_ADMIN_PASSWORD. Sem isso, crie o administrador no primeiro acesso (POST /api/auth/setup).
  const em = process.env.SEED_ADMIN_EMAIL?.toLowerCase(), pw = process.env.SEED_ADMIN_PASSWORD;
  if (em && pw) {
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) throw new Error('SEED_ADMIN_PASSWORD precisa ter 8+ caracteres, com letras e números');
    await prisma.user.upsert({ where: { email: em }, update: {}, create: { name: process.env.SEED_ADMIN_NAME || 'Administrador', email: em, role: 'ADMIN', password: hash(pw) } });
  }

  // Taxas das adquirentes (valores de exemplo: confira com o seu contrato)
  for (const a of [
    { name: 'Stone', debitFeePct: 1.19, creditFeePct: 2.99, installmentFeePct: 3.49, anticipationFeePct: 1.99, settlementDaysDebit: 1, settlementDaysCredit: 30 },
    { name: 'PagBank', debitFeePct: 1.39, creditFeePct: 3.19, installmentFeePct: 3.89, anticipationFeePct: 2.19, settlementDaysDebit: 1, settlementDaysCredit: 30 },
    { name: 'Mercado Pago', debitFeePct: 1.29, creditFeePct: 3.05, installmentFeePct: 3.79, anticipationFeePct: 2.09, settlementDaysDebit: 1, settlementDaysCredit: 14 },
  ]) if (!(await prisma.acquirer.findFirst({ where: { name: a.name } }))) await prisma.acquirer.create({ data: a });


  // Dados de demonstração (fornecedores, produtos, clientes): somente com SEED_DEMO=1
  if (process.env.SEED_DEMO === '1') {
    const sup = await Promise.all([
      { legalName: 'Laticínios Vale do Sul Ltda', tradeName: 'Vale Lácteos', cnpj: '11222333000181', orderEmail: 'pedidos@valelacteos.com.br', paymentTerms: '28 dias, boleto', phones: ['(81) 3333-1200'] },
      { legalName: 'Bebidas Norte S.A.', tradeName: 'Norte Bebidas', cnpj: '45723174000110', orderEmail: 'compras@nortebebidas.com.br', paymentTerms: '30/60 dias', phones: ['(81) 3444-9000'] },
    ].map((s) => prisma.supplier.upsert({ where: { cnpj: s.cnpj }, update: {}, create: s })));

    const catalog = [
      { sku: 'LEI-001', barcode: '7891000100103', name: 'Leite UHT Integral 1L (cx 12)', category: 'Laticínios', unitsPerBox: 12, ncm: '04012010', shelfLifeDays: 120, minStock: 100, criticalStock: 40, avgCost: 52, replacementCost: 54.5, retailPrice: 74.9, sup: 0, tiers: [[1, 66], [10, 63], [50, 60.5]], lot: 140, exp: 12 },
      { sku: 'SUC-020', barcode: '7891000200200', name: 'Suco de Uva Integral 1L (cx 6)', category: 'Bebidas', unitsPerBox: 6, ncm: '20096100', shelfLifeDays: 365, minStock: 80, criticalStock: 30, avgCost: 41, replacementCost: 43, retailPrice: 59.9, sup: 1, tiers: [[1, 53], [20, 50], [80, 47.5]], lot: 210, exp: 36 },
      { sku: 'ARR-030', barcode: '7891000300307', name: 'Arroz Branco Tipo 1 (fardo 30kg)', category: 'Mercearia', unit: 'FD', ncm: '10063021', shelfLifeDays: 540, minStock: 20, criticalStock: 8, avgCost: 140, replacementCost: 145, retailPrice: 189, sup: 1, tiers: [[1, 168], [5, 160], [20, 152]], lot: 60, exp: 200 },
      { sku: 'QJM-040', barcode: '2000000000401', name: 'Queijo Mussarela fatiado (kg)', category: 'Frios', unit: 'KG', sellsByWeight: true, ncm: '04061010', shelfLifeDays: 45, minStock: 30, criticalStock: 10, avgCost: 31, replacementCost: 33, retailPrice: 49.9, sup: 0, tiers: [[1, 42], [10, 39.5]], lot: 55, exp: 20 },
    ];
    for (const { sup: si, tiers, lot, exp, ...p } of catalog) {
      const prod = await prisma.product.upsert({ where: { sku: p.sku }, update: {}, create: p });
      await prisma.priceTier.createMany({ data: tiers.map(([minQty, price]) => ({ productId: prod.id, minQty, price })), skipDuplicates: true });
      await prisma.productSupplier.upsert({ where: { supplierId_productId: { supplierId: sup[si].id, productId: prod.id } }, update: {}, create: { supplierId: sup[si].id, productId: prod.id, supplierSku: p.sku, lastCost: p.replacementCost } });
      await prisma.stockBatch.upsert({ where: { productId_lotCode: { productId: prod.id, lotCode: 'SEED-1' } }, update: {}, create: { productId: prod.id, lotCode: 'SEED-1', expiresAt: days(exp), quantity: lot, unitCost: p.avgCost } });
    }

    for (const c of [{ name: 'Mercadinho Boa Vista', document: '12345678000190', creditLimit: 30000 }, { name: 'Restaurante Sabor do Mar', document: '98765432000155', creditLimit: 20000 }, { name: 'Padaria Pão Quente', document: '55443322000166', creditLimit: 10000 }])
      if (!(await prisma.customer.findUnique({ where: { document: c.document } }))) await prisma.customer.create({ data: c });

    
  }

  console.log('\nSeed concluído.' + (em && pw ? ` Administrador: ${em}` : ' Crie o administrador em POST /api/auth/setup (primeiro acesso).') + '\n');
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
